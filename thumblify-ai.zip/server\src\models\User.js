import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true, select: false },
  credits: { type: Number, min: 0, default: 20 },
  brandKit: {
    channelName: { type: String, default: '', maxlength: 100 },
    defaultScript: { type: String, enum: ['Kannada', 'English'], default: 'Kannada' },
    primaryColor: { type: String, default: '#f59e0b' },
    secondaryColor: { type: String, default: '#ef4444' },
    defaultFont: { type: String, default: 'Nirmala UI' },
    category: { type: String, default: 'Vlog' }
  }
}, { timestamps: true });

export default mongoose.model('User', userSchema);
