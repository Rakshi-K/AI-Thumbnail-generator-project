import { Router } from 'express';
import Project from '../models/Project.js';
import { requireAuth } from '../middleware/auth.js';
const router = Router();
router.use(requireAuth);
router.get('/', async (req, res, next) => {
  try { res.json({ projects: await Project.find({ user: req.userId }).sort({ createdAt: -1 }).limit(100).lean() }); } catch (e) { next(e); }
});
router.post('/', async (req, res, next) => {
  try {
    const title = String(req.body.title || '').trim().slice(0,160);
    if (!title) return res.status(400).json({ message: 'Project title is required.' });
    const thumbnails = Array.isArray(req.body.thumbnails) ? req.body.thumbnails.slice(0,5).map(t => ({ url: String(t.url || '').slice(0,500), score: Math.max(0,Math.min(100,Number(t.score)||0)), label: String(t.label || '').slice(0,80) })) : [];
    const project = await Project.create({ user: req.userId, title, language: req.body.language === 'Kannada' ? 'Kannada' : 'English', category: String(req.body.category || 'Vlog').slice(0,40), thumbnails });
    res.status(201).json({ project });
  } catch (e) { next(e); }
});
router.delete('/:id', async (req, res, next) => {
  try {
    const result = await Project.findOneAndDelete({ _id: req.params.id, user: req.userId });
    if (!result) return res.status(404).json({ message: 'Project not found.' });
    res.json({ ok: true });
  } catch (e) { next(e); }
});
export default router;
