import { Router } from 'express';
import { upload, publicUrl } from '../middleware/upload.js';
import { requireAuth } from '../middleware/auth.js';
import { imageStats } from '../services/vision.js';
const router = Router();
router.post('/analyze', requireAuth, upload.single('image'), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ message: 'Upload an image to analyze.' });
    const { metrics, score, componentScores } = await imageStats(req.file.path);
    const recommendations = [];
    if (metrics.brightness < 45) recommendations.push('Increase brightness, especially around faces and the title area.');
    if (metrics.brightness > 210) recommendations.push('Reduce highlights so important details do not look washed out.');
    if (componentScores.contrast < 45) recommendations.push('Increase contrast between the title, subject and background.');
    if (metrics.saturation < 20) recommendations.push('Consider a more intentional accent colour to improve visual energy.');
    if (metrics.colorBalance < 55) recommendations.push('Review colour casts; balance warm and cool channels for a more natural image.');
    if (metrics.aspectRatioCompliance < 80 || metrics.width < 1280 || metrics.height < 720) recommendations.push('Export at 1280 × 720 pixels (16:9) or larger for YouTube.');
    if (!recommendations.length) recommendations.push('The measured image-quality signals look balanced. Preview at mobile size before publishing.');
    res.json({ score, metrics, componentScores, recommendations, scoreType: 'six-factor heuristic image-quality estimate; not measured CTR', imageUrl: publicUrl(req.file.filename) });
  } catch (e) { next(e); }
});
export default router;
