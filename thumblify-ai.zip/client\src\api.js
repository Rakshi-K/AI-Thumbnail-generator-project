const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
export const ASSET = import.meta.env.VITE_ASSET_URL || 'http://localhost:5000';
export function getToken() { return localStorage.getItem('thumblify_token'); }
export async function api(path, options = {}) {
  const headers = { ...(options.headers || {}) };
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (options.body && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
  const response = await fetch(`${API}${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || `Request failed (${response.status})`);
  return data;
}
export const assetUrl = (url) => url?.startsWith('http') ? url : `${ASSET}${url || ''}`;
