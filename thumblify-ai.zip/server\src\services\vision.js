import path from 'node:path';
import fs from 'node:fs/promises';
import { pathToFileURL, fileURLToPath } from 'node:url';
import sharp from 'sharp';

const here = path.dirname(fileURLToPath(import.meta.url));
const serverRoot = path.resolve(here, '..', '..');
const modelDir = path.resolve(serverRoot, process.env.FACE_API_MODELS_DIR || 'models/face-api');
let faceApiState;
async function loadFaceApi() {
  if (faceApiState !== undefined) return faceApiState;
  try {
    const faceapi = await import('@vladmandic/face-api');
    const canvas = await import('@napi-rs/canvas');
    faceapi.env.monkeyPatch({ Canvas: canvas.Canvas, Image: canvas.Image, ImageData: canvas.ImageData });
    await faceapi.nets.ssdMobilenetv1.loadFromDisk(modelDir);
    await faceapi.nets.faceLandmark68Net.loadFromDisk(modelDir);
    await faceapi.nets.faceExpressionNet.loadFromDisk(modelDir);
    faceApiState = { faceapi, canvas };
  } catch {
    faceApiState = null;
  }
  return faceApiState;
}

export async function removePersonBackground(filePath) {
  if (process.env.ENABLE_BACKGROUND_REMOVAL === 'false') return { buffer: await fs.readFile(filePath), removed: false, method: 'disabled' };
  try {
    const { removeBackground } = await import('@imgly/background-removal-node');
    const result = await removeBackground(pathToFileURL(filePath).href);
    const buffer = Buffer.isBuffer(result) ? result : result instanceof Uint8Array ? Buffer.from(result) : Buffer.from(await result.arrayBuffer());
    return { buffer, removed: true, method: 'imgly-background-removal' };
  } catch (error) {
    // Do not fail the whole request if the model runtime cannot initialize; surface the fallback in result metadata.
    return { buffer: await fs.readFile(filePath), removed: false, method: 'original-image-fallback', warning: 'Background-removal runtime/model could not initialize.' };
  }
}

export async function analyzeFace(filePath) {
  const runtime = await loadFaceApi();
  if (!runtime) return { detected: false, count: 0, attention: 0.5, landmarks: false, expressions: false, method: 'fallback-heuristic', note: 'Face model weights/runtime are not available. Add SSD-MobileNet, FaceLandmark68 and FaceExpression model files to FACE_API_MODELS_DIR.' };
  try {
    const img = await runtime.canvas.loadImage(filePath);
    const detections = await runtime.faceapi.detectAllFaces(img, new runtime.faceapi.SsdMobilenetv1Options({ minConfidence: 0.35 })).withFaceLandmarks().withFaceExpressions();
    const w = img.width || 1, h = img.height || 1;
    const scores = detections.map(d => {
      const b = d.detection.box;
      const area = Math.min(1, (b.width * b.height) / (w * h));
      const cx = (b.x + b.width / 2) / w, cy = (b.y + b.height / 2) / h;
      const distance = Math.min(1, Math.hypot(cx - 0.5, cy - 0.45) / 0.71);
      const expressions = d.expressions || {};
      const expression = Math.max(0, ...Object.entries(expressions).filter(([k]) => k !== 'neutral').map(([,v]) => v));
      return 0.3 * d.detection.score + 0.25 * Math.min(1, area * 8) + 0.25 * (1 - distance) + 0.2 * expression;
    });
    return { detected: detections.length > 0, count: detections.length, attention: scores.length ? scores.reduce((a,b)=>a+b,0)/scores.length : 0.35, landmarks: true, expressions: true, method: 'ssd-mobilenet-landmarks-expressions' };
  } catch {
    return { detected: false, count: 0, attention: 0.5, landmarks: false, expressions: false, method: 'fallback-heuristic', note: 'Face analysis failed for this image; heuristic scoring used.' };
  }
}

export async function imageStats(filePath) {
  const metadata = await sharp(filePath).metadata();
  const stats = await sharp(filePath).resize(64, 36, { fit: 'fill' }).stats();
  const channels = stats.channels.slice(0, 3);
  const brightness = channels.reduce((s,c)=>s+c.mean,0) / channels.length;
  const contrast = channels.reduce((s,c)=>s+c.stdev,0) / channels.length;
  const saturation = Math.min(100, Math.round((Math.max(...channels.map(c=>c.mean))-Math.min(...channels.map(c=>c.mean)))*1.1));
  const exposure = Math.max(0, 100 - Math.round(Math.abs(brightness - 127.5) / 1.275));
  const colorBalance = Math.max(0, 100 - Math.round((Math.max(...channels.map(c=>c.mean))-Math.min(...channels.map(c=>c.mean))) * 0.8));
  const aspectRatio = metadata.width && metadata.height ? metadata.width / metadata.height : 0;
  const aspectCompliance = Math.max(0, 100 - Math.round(Math.abs(aspectRatio - 16/9) * 80));
  const brightnessScore = Math.max(0, 100 - Math.round(Math.abs(brightness - 127.5) / 1.275));
  const contrastScore = Math.min(100, Math.round(contrast * 1.35));
  const metrics = {
    brightness: Math.round(brightness), contrast: Math.round(contrast), saturation,
    exposure, colorBalance, aspectRatio: Number(aspectRatio.toFixed(3)), aspectRatioCompliance: aspectCompliance,
    width: metadata.width || 0, height: metadata.height || 0,
    dimensions: metadata.width && metadata.height ? `${metadata.width}×${metadata.height}` : 'unknown'
  };
  const score = Math.round(brightnessScore * 0.18 + contrastScore * 0.2 + saturation * 0.12 + exposure * 0.18 + colorBalance * 0.12 + aspectCompliance * 0.2);
  return { metadata, metrics, score, componentScores: { brightness: brightnessScore, contrast: contrastScore, saturation, exposure, colorBalance, aspectRatio: aspectCompliance } };
}
