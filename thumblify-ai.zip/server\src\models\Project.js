import mongoose from 'mongoose';
const projectSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, maxlength: 160 },
  language: { type: String, enum: ['English', 'Kannada'], default: 'English' },
  category: { type: String, default: 'Vlog', maxlength: 40 },
  thumbnails: [{ url: String, score: Number, label: String }],
  createdAt: { type: Date, default: Date.now }
}, { timestamps: true });
export default mongoose.model('Project', projectSchema);
