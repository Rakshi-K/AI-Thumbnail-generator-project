import { Router } from 'express';
import { upload, publicUrl } from '../middleware/upload.js';
import { requireAuth } from '../middleware/auth.js';
import { composeVariants } from '../services/composer.js';
import Thumbnail from '../models/Thumbnail.js';
import User from '../models/User.js';
const router = Router();
router.get('/history', requireAuth, async (req, res, next) => {
  try {
    const generations = await Thumbnail.find({ user: req.userId }).sort({ createdAt: -1 }).limit(100).lean();
    res.json({ generations });
  } catch (e) { next(e); }
});
router.get('/analytics', requireAuth, async (req, res, next) => {
  try {
    const rows = await Thumbnail.find({ user: req.userId }).select('category bestScore createdAt').lean();
    const total = rows.length;
    const scores = rows.map(r => Number(r.bestScore) || 0);
    const byCategory = {};
    for (const row of rows) byCategory[row.category || 'Vlog'] = (byCategory[row.category || 'Vlog'] || 0) + 1;
    res.json({ totalGenerations: total, averageScore: total ? Math.round(scores.reduce((a,b)=>a+b,0)/total) : 0, bestScore: scores.length ? Math.max(...scores) : 0, byCategory, note: 'These are generation-quality scores, not YouTube impressions or click-through analytics.' });
  } catch (e) { next(e); }
});

router.post('/generate', requireAuth, upload.fields([{ name: 'people', maxCount: 6 }, { name: 'background', maxCount: 1 }]), async (req, res, next) => {
  try {
    const people = req.files?.people || [];
    const background = req.files?.background?.[0];
    const title = String(req.body.title || '').trim();
    if (people.length < 1 || people.length > 6) return res.status(400).json({ message: 'Upload between 1 and 6 people photos.' });
    if (!title || title.length > 140) return res.status(400).json({ message: 'Title is required and must be 140 characters or fewer.' });
    const user = await User.findById(req.userId);
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });
    if (Number.isFinite(user.credits) && user.credits < 1) return res.status(402).json({ message: 'No generation credits remain. Add a credit plan before generating more thumbnails.' });
    const language = req.body.language === 'Kannada' ? 'Kannada' : 'English';
    const category = String(req.body.category || 'Vlog').slice(0, 40);
    const style = String(req.body.style || 'Cinematic').slice(0, 40);
    const emoji = String(req.body.emoji || '').slice(0, 8);
    const variants = await composeVariants({ people, background, title, category, style, emoji });
    const publicVariants = variants.map(v => ({ ...v, url: publicUrl(decodeURIComponent(v.url.split('/').pop())) }));
    await Thumbnail.create({ user: req.userId, title, category, language, emoji, variants: publicVariants.map(v => ({ url: v.url, score: v.score, label: v.label, layout: v.layout, factors: v.factors })), bestScore: publicVariants[0]?.score || 0 });
    user.credits = Math.max(0, (Number.isFinite(user.credits) ? user.credits : 20) - 1);
    await user.save();
    res.json({ variants: publicVariants, language, creditsRemaining: user.credits, mode: 'ranked-layout-composition', note: 'Generated ten layout candidates, scored them with seven heuristic factors, and returned the top five. Face/background removal status is included per candidate; fallback is reported when model runtime is unavailable.' });
  } catch (e) { next(e); }
});
export default router;
