import { Router } from 'express';

const router = Router();

const TEMPLATES = [
  {
    id: 'kannada-serial',
    title: 'ಅವಳ ಜೀವನದಲ್ಲಿ ಹೊಸ ತಿರುವು!',
    language: 'Kannada',
    category: 'Kannada Serial',
    style: 'Cinematic',
    emoji: '🔥',
    layout: 'banner-impact',
    description: 'High-drama soap opera / serial format with fiery action banner and high emotional contrast.',
    gradient: 'linear-gradient(135deg, #7f1d1d, #991b1b 50%, #450a0a)'
  },
  {
    id: 'travel-vlog',
    title: 'ನಿಮಗೆ ಗೊತ್ತಾ? Karnataka Unexplored',
    language: 'Kannada',
    category: 'Vlog',
    style: 'Cinematic',
    emoji: '✨',
    layout: 'hero-left',
    description: 'Cinematic travel adventure thumbnail with golden-hour backlight and 3D punchy title.',
    gradient: 'linear-gradient(135deg, #1e1b4b, #312e81 50%, #f59e0b)'
  },
  {
    id: 'breaking-news',
    title: 'BIG BREAKING: ಮಹತ್ವದ ತೀರ್ಮಾನ ಪ್ರಕಟ!',
    language: 'Kannada',
    category: 'News',
    style: 'News editorial',
    emoji: '🚨',
    layout: 'sunset-split',
    description: 'Urgent broadcast headline aesthetic with high-contrast electric badges and crisp text.',
    gradient: 'linear-gradient(135deg, #0c4a6e, #0284c7 50%, #e0f2fe)'
  },
  {
    id: 'tech-review',
    title: 'Is This The Ultimate AI Gadget in 2026?',
    language: 'English',
    category: 'Education',
    style: 'Bold & vibrant',
    emoji: '⚡',
    layout: 'cyber-glow',
    description: 'High-tech neon cyan and magenta cyber lighting with glassmorphic title badge.',
    gradient: 'linear-gradient(135deg, #0f172a, #1e1b4b 50%, #06b6d4)'
  },
  {
    id: 'gaming-stream',
    title: 'INSANE 1v4 CLUTCH VICTORY!',
    language: 'English',
    category: 'Gaming',
    style: 'Bold & vibrant',
    emoji: '👑',
    layout: 'banner-impact',
    description: 'High-octane esports gaming thumbnail with explosive lighting and bold typography.',
    gradient: 'linear-gradient(135deg, #4c0519, #be123c 50%, #fb7185)'
  },
  {
    id: 'devotional',
    title: 'ದೈವಿಕ ಆಶೀರ್ವಾದ: Sacred Temple Darshan',
    language: 'Kannada',
    category: 'Devotional',
    style: 'Devotional glow',
    emoji: '🙏',
    layout: 'hero-left',
    description: 'Spiritual golden aura with radiant sunburst lighting and divine typography.',
    gradient: 'linear-gradient(135deg, #451a03, #b45309 50%, #fde68a)'
  },
  {
    id: 'comedy-skit',
    title: 'When Friends Meet After 5 Years! 😂',
    language: 'English',
    category: 'Comedy',
    style: 'Bold & vibrant',
    emoji: '🤣',
    layout: 'split-screen',
    description: 'Relatable reaction comedy format with split juxtaposition and expressive characters.',
    gradient: 'linear-gradient(135deg, #365314, #65a30d 50%, #d9f99d)'
  },
  {
    id: 'cooking-recipe',
    title: 'Secret Hotel Masala Dosa Recipe at Home',
    language: 'English',
    category: 'Cooking',
    style: 'Minimal',
    emoji: '😋',
    layout: 'hero-right',
    description: 'Warm appetizing culinary presentation with clear hero staging and clean recipe title.',
    gradient: 'linear-gradient(135deg, #7c2d12, #ea580c 50%, #fed7aa)'
  }
];

router.get('/', (_req, res) => {
  res.json({ templates: TEMPLATES });
});

export default router;
