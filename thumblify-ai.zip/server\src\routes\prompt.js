import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
const router = Router();
router.post('/refine', requireAuth, async (req, res) => {
  const prompt = String(req.body.prompt || '').trim();
  const language = req.body.language === 'Kannada' ? 'Kannada' : 'English';
  if (!prompt || prompt.length > 2000) return res.status(400).json({ message: 'Prompt is required (maximum 2000 characters).' });
  const key = process.env.GROQ_API_KEY;
  if (!key) {
    return res.json({ refinedPrompt: `${prompt}. Create a professional 16:9 YouTube thumbnail, strong focal subject, high contrast, clean negative space for readable ${language} title text, crisp edges, cinematic lighting, mobile-first readability, no watermark.`, mode: 'local-template', note: 'Set GROQ_API_KEY to enable AI-powered prompt refinement.' });
  }
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: 'llama-3.3-70b-versatile', temperature: 0.6, messages: [
        { role: 'system', content: `You are a professional thumbnail art director. Refine prompts for 16:9 creator thumbnails. Preserve user intent. Use ${language} for any title suggestions. Return only the refined prompt.` },
        { role: 'user', content: prompt }
      ] })
    });
    if (!response.ok) return res.status(502).json({ message: 'Prompt provider request failed. Check the server API key and provider status.' });
    const data = await response.json();
    res.json({ refinedPrompt: data.choices?.[0]?.message?.content?.trim() || prompt, mode: 'groq' });
  } catch { res.status(502).json({ message: 'Could not reach the prompt provider.' }); }
});
export default router;
