import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import mongoose from 'mongoose';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import authRoutes from './routes/auth.js';
import thumbnailRoutes from './routes/thumbnails.js';
import analyzerRoutes from './routes/analyzer.js';
import promptRoutes from './routes/prompt.js';
import projectRoutes from './routes/projects.js';
import templateRoutes from './routes/templates.js';

const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
const uploadDir = path.resolve(here, '..', process.env.UPLOAD_DIR || 'uploads');
fs.mkdirSync(uploadDir, { recursive: true });
app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }));
app.use(express.json({ limit: '1mb' }));
app.use('/uploads', express.static(uploadDir, { dotfiles: 'deny', index: false }));
app.use('/api', rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: 'draft-7', legacyHeaders: false }));
app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'thumblify-ai-api' }));
app.use('/api/auth', authRoutes);
app.use('/api/thumbnails', thumbnailRoutes);
app.use('/api/analyzer', analyzerRoutes);
app.use('/api/prompt', promptRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/templates', templateRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  if (err.name === 'MulterError') return res.status(400).json({ message: err.message });
  res.status(err.status || 500).json({ message: err.status ? err.message : 'Internal server error' });
});

const port = Number(process.env.PORT || 5000);
if (process.env.NODE_ENV !== 'test') {
  if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) {
    console.error('JWT_SECRET must be at least 32 characters. Copy .env.example and set a secure secret.');
    process.exit(1);
  }
  const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/thumblify_ai';
  mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 })
    .then(() => {
      console.log('MongoDB connected successfully');
      app.listen(port, () => console.log(`Thumblify API listening on http://localhost:${port}`));
    })
    .catch((err) => {
      console.warn('Primary MongoDB connection failed:', err.message);
      if (uri.includes('mongodb.net')) {
        console.log('Attempting local MongoDB fallback (mongodb://127.0.0.1:27017/thumblify_ai)...');
        mongoose.connect('mongodb://127.0.0.1:27017/thumblify_ai', { serverSelectionTimeoutMS: 3000 })
          .then(() => {
            console.log('Local MongoDB connected successfully');
            app.listen(port, () => console.log(`Thumblify API listening on http://localhost:${port}`));
          })
          .catch(() => {
            console.warn('Starting Express server in resilient mode...');
            app.listen(port, () => console.log(`Thumblify API listening on http://localhost:${port} (resilient mode)`));
          });
      } else {
        console.warn('Starting Express server in resilient mode...');
        app.listen(port, () => console.log(`Thumblify API listening on http://localhost:${port} (resilient mode)`));
      }
    });
}
export default app;
