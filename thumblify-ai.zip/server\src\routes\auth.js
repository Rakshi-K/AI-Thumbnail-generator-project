import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
const makeToken = (user) => jwt.sign({ sub: user.id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '7d', issuer: 'thumblify-ai' });
const safeUser = (u) => ({
  id: u.id,
  name: u.name,
  email: u.email,
  credits: typeof u.credits === 'number' ? u.credits : 20,
  brandKit: u.brandKit || {
    channelName: '',
    defaultScript: 'Kannada',
    primaryColor: '#f59e0b',
    secondaryColor: '#ef4444',
    defaultFont: 'Nirmala UI',
    category: 'Vlog'
  }
});

router.post('/register', async (req, res, next) => {
  try {
    const name = String(req.body.name || '').trim();
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (name.length < 2 || name.length > 80) return res.status(400).json({ message: 'Name must be 2–80 characters.' });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ message: 'Enter a valid email address.' });
    if (password.length < 10 || password.length > 128) return res.status(400).json({ message: 'Password must be 10–128 characters.' });
    if (await User.exists({ email })) return res.status(409).json({ message: 'An account with this email already exists.' });
    const user = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12) });
    res.status(201).json({ token: makeToken(user), user: safeUser(user) });
  } catch (e) { if (e.code === 11000) return res.status(409).json({ message: 'Email already registered.' }); next(e); }
});

router.post('/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    const user = await User.findOne({ email }).select('+passwordHash');
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ message: 'Email or password is incorrect.' });
    res.json({ token: makeToken(user), user: safeUser(user) });
  } catch (e) { next(e); }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });
    res.json({ user: safeUser(user) });
  } catch (e) { next(e); }
});

router.put('/brand-kit', requireAuth, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId);
    if (!user) return res.status(401).json({ message: 'Account no longer exists.' });
    user.brandKit = {
      channelName: String(req.body.channelName || user.brandKit?.channelName || '').slice(0, 100),
      defaultScript: req.body.defaultScript === 'English' ? 'English' : 'Kannada',
      primaryColor: String(req.body.primaryColor || user.brandKit?.primaryColor || '#f59e0b').slice(0, 20),
      secondaryColor: String(req.body.secondaryColor || user.brandKit?.secondaryColor || '#ef4444').slice(0, 20),
      defaultFont: String(req.body.defaultFont || user.brandKit?.defaultFont || 'Nirmala UI').slice(0, 50),
      category: String(req.body.category || user.brandKit?.category || 'Vlog').slice(0, 40)
    };
    await user.save();
    res.json({ message: 'Brand Kit updated successfully.', brandKit: user.brandKit });
  } catch (e) { next(e); }
});

export default router;
