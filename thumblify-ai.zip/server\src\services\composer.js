import sharp from 'sharp';
import path from 'node:path';
import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { createCanvas, loadImage } from '@napi-rs/canvas';
import { removePersonBackground, analyzeFace, imageStats } from './vision.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const uploadDir = path.resolve(here, '..', '..', process.env.UPLOAD_DIR || 'uploads');
const W = 1280, H = 720;

const themes = [
  {
    name: 'Cinematic Hero Pop',
    mode: 'hero-left',
    accent: '#f59e0b',
    glowColor: 'rgba(245, 158, 11, 0.45)',
    banner: null,
    textColor1: ['#FFF886', '#F59E0B'],
    textColor2: ['#FFFFFF', '#E2E8F0'],
    badgeBg: 'rgba(245, 158, 11, 0.22)',
    badgeBorder: '#fbbf24',
    badgeText: '#fef08a'
  },
  {
    name: 'Action Crimson Banner',
    mode: 'banner-impact',
    accent: '#ef4444',
    glowColor: 'rgba(239, 68, 68, 0.5)',
    banner: 'crimson',
    textColor1: ['#FEF08A', '#FACC15'],
    textColor2: ['#FFFFFF', '#F8FAFC'],
    badgeBg: '#b91c1c',
    badgeBorder: '#facc15',
    badgeText: '#ffffff'
  },
  {
    name: 'Electric Neon Night',
    mode: 'cyber-glow',
    accent: '#06b6d4',
    glowColor: 'rgba(6, 182, 212, 0.45)',
    banner: 'glass-cyan',
    textColor1: ['#A5F3FC', '#06B6D4'],
    textColor2: ['#FDF4FF', '#E879F9'],
    badgeBg: 'rgba(6, 182, 212, 0.25)',
    badgeBorder: '#22d3ee',
    badgeText: '#cffafe'
  },
  {
    name: 'Dramatic Sunset Horizon',
    mode: 'sunset-split',
    accent: '#fb923c',
    glowColor: 'rgba(251, 146, 60, 0.45)',
    banner: 'glass-dark',
    textColor1: ['#FED7AA', '#FB923C'],
    textColor2: ['#FFFFFF', '#F1F5F9'],
    badgeBg: 'rgba(15, 23, 42, 0.85)',
    badgeBorder: '#fb923c',
    badgeText: '#fed7aa'
  },
  {
    name: 'Emotional Split Screen',
    mode: 'split-screen',
    accent: '#eab308',
    glowColor: 'rgba(234, 179, 8, 0.45)',
    banner: null,
    textColor1: ['#FEF9C3', '#EAB308'],
    textColor2: ['#FFFFFF', '#E2E8F0'],
    badgeBg: 'rgba(234, 179, 8, 0.25)',
    badgeBorder: '#facc15',
    badgeText: '#fef08a'
  },
  {
    name: 'Golden Spotlight Focus',
    mode: 'hero-right',
    accent: '#eab308',
    glowColor: 'rgba(234, 179, 8, 0.45)',
    banner: null,
    textColor1: ['#FEF9C3', '#EAB308'],
    textColor2: ['#FFFFFF', '#E2E8F0'],
    badgeBg: 'rgba(234, 179, 8, 0.2)',
    badgeBorder: '#facc15',
    badgeText: '#fef08a'
  },
  {
    name: 'Vibrant Creator Gold',
    mode: 'hero-left',
    accent: '#eab308',
    glowColor: 'rgba(234, 179, 8, 0.4)',
    banner: null,
    textColor1: ['#FEF08A', '#EAB308'],
    textColor2: ['#FFFFFF', '#F8FAFC'],
    badgeBg: 'rgba(202, 138, 4, 0.25)',
    badgeBorder: '#facc15',
    badgeText: '#fef9c3'
  },
  {
    name: 'Dramatic Noir Thriller',
    mode: 'banner-impact',
    accent: '#dc2626',
    glowColor: 'rgba(220, 38, 38, 0.45)',
    banner: 'crimson',
    textColor1: ['#FCA5A5', '#EF4444'],
    textColor2: ['#FFFFFF', '#E2E8F0'],
    badgeBg: '#7f1d1d',
    badgeBorder: '#ef4444',
    badgeText: '#fee2e2'
  },
  {
    name: 'Royal Velvet Drama',
    mode: 'hero-left',
    accent: '#c084fc',
    glowColor: 'rgba(192, 132, 252, 0.4)',
    banner: 'glass-dark',
    textColor1: ['#F3E8FF', '#C084FC'],
    textColor2: ['#FEF08A', '#FACC15'],
    badgeBg: 'rgba(88, 28, 135, 0.85)',
    badgeBorder: '#c084fc',
    badgeText: '#f5d0fe'
  },
  {
    name: 'Broadcast Editorial',
    mode: 'sunset-split',
    accent: '#38bdf8',
    glowColor: 'rgba(56, 189, 248, 0.4)',
    banner: 'glass-cyan',
    textColor1: ['#BAE6FD', '#38BDF8'],
    textColor2: ['#FFFFFF', '#F8FAFC'],
    badgeBg: 'rgba(12, 74, 110, 0.85)',
    badgeBorder: '#38bdf8',
    badgeText: '#e0f2fe'
  }
];

export function wrapText(text, maxChars = 18, maxLines = 3) {
  const words = String(text || 'YOUR TITLE').trim().split(/\s+/).filter(Boolean);
  const lines = [];
  let line = '';
  for (const word of words) {
    if ((line + ' ' + word).trim().length > maxChars && line) {
      lines.push(line);
      line = word;
    } else {
      line = (line + ' ' + word).trim();
    }
  }
  if (line) lines.push(line);
  if (lines.length <= maxLines) return lines;
  return [...lines.slice(0, maxLines - 1), `${lines.slice(maxLines - 1).join(' ').slice(0, maxChars - 1)}…`];
}

// Procedural background generator when user doesn't provide a background
function renderProceduralBackground(ctx, theme, category = 'Vlog', style = 'Cinematic') {
  const isDramatic = /serial|drama|devotional|cinematic/i.test(category + ' ' + style);
  const isAction = /action|comedy|vlog/i.test(category + ' ' + style);
  const isCyber = /gaming|tech/i.test(category + ' ' + style);

  if (theme.mode === 'split-screen') {
    // Left half: Grayscale Noir
    const leftGrad = ctx.createLinearGradient(0, 0, W * 0.46, H);
    leftGrad.addColorStop(0, '#111827');
    leftGrad.addColorStop(0.5, '#030712');
    leftGrad.addColorStop(1, '#000000');
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, W * 0.46, H);
    ctx.clip();
    ctx.fillStyle = leftGrad;
    ctx.fillRect(0, 0, W * 0.46, H);

    const leftFlare = ctx.createRadialGradient(W * 0.2, H * 0.4, 20, W * 0.2, H * 0.4, 400);
    leftFlare.addColorStop(0, 'rgba(255, 255, 255, 0.18)');
    leftFlare.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = leftFlare;
    ctx.fillRect(0, 0, W * 0.46, H);
    ctx.restore();

    // Right half: Warm Amber
    const rightGrad = ctx.createRadialGradient(W * 0.75, H * 0.45, 50, W * 0.75, H * 0.45, 550);
    rightGrad.addColorStop(0, '#7c2d12');
    rightGrad.addColorStop(0.45, '#431407');
    rightGrad.addColorStop(1, '#0c0402');
    ctx.save();
    ctx.beginPath();
    ctx.rect(W * 0.46, 0, W * 0.54, H);
    ctx.clip();
    ctx.fillStyle = rightGrad;
    ctx.fillRect(W * 0.46, 0, W * 0.54, H);

    const rightFlare = ctx.createRadialGradient(W * 0.8, H * 0.4, 30, W * 0.8, H * 0.4, 450);
    rightFlare.addColorStop(0, 'rgba(251, 191, 36, 0.45)');
    rightFlare.addColorStop(0.5, 'rgba(234, 88, 12, 0.18)');
    rightFlare.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = rightFlare;
    ctx.fillRect(W * 0.46, 0, W * 0.54, H);
    ctx.restore();

    // Seam line
    ctx.save();
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = '#f59e0b';
    ctx.shadowBlur = 18;
    ctx.beginPath();
    ctx.moveTo(W * 0.46, 0);
    ctx.lineTo(W * 0.46, H);
    ctx.stroke();
    ctx.restore();
    return;
  }

  if (theme.mode === 'banner-impact' || isAction) {
    const grad = ctx.createRadialGradient(W * 0.35, H * 0.45, 60, W * 0.5, H * 0.5, W * 0.85);
    grad.addColorStop(0, '#7f1d1d');
    grad.addColorStop(0.45, '#450a0a');
    grad.addColorStop(0.85, '#180202');
    grad.addColorStop(1, '#080101');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    const flare = ctx.createRadialGradient(W * 0.3, H * 0.42, 20, W * 0.3, H * 0.42, 500);
    flare.addColorStop(0, 'rgba(249, 115, 22, 0.4)');
    flare.addColorStop(0.5, 'rgba(234, 88, 12, 0.18)');
    flare.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = flare;
    ctx.fillRect(0, 0, W, H);
  } else if (theme.mode === 'cyber-glow' || isCyber) {
    const grad = ctx.createRadialGradient(W * 0.4, H * 0.5, 80, W * 0.5, H * 0.5, W * 0.85);
    grad.addColorStop(0, '#1e1b4b');
    grad.addColorStop(0.5, '#0f172a');
    grad.addColorStop(1, '#020617');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    const flare = ctx.createRadialGradient(W * 0.28, H * 0.45, 30, W * 0.28, H * 0.45, 520);
    flare.addColorStop(0, 'rgba(6, 182, 212, 0.38)');
    flare.addColorStop(0.55, 'rgba(59, 130, 246, 0.15)');
    flare.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = flare;
    ctx.fillRect(0, 0, W, H);
  } else if (isDramatic) {
    const grad = ctx.createRadialGradient(W * 0.35, H * 0.45, 60, W * 0.5, H * 0.5, W * 0.85);
    grad.addColorStop(0, '#2e1065');
    grad.addColorStop(0.4, '#1e1b4b');
    grad.addColorStop(0.75, '#0f172a');
    grad.addColorStop(1, '#020617');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    const flare = ctx.createRadialGradient(W * 0.3, H * 0.4, 30, W * 0.3, H * 0.4, 520);
    flare.addColorStop(0, 'rgba(251, 191, 36, 0.42)');
    flare.addColorStop(0.45, 'rgba(217, 119, 6, 0.18)');
    flare.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = flare;
    ctx.fillRect(0, 0, W, H);
  } else {
    const grad = ctx.createRadialGradient(W * 0.35, H * 0.45, 70, W * 0.5, H * 0.5, W * 0.85);
    grad.addColorStop(0, '#1e293b');
    grad.addColorStop(0.4, '#0f172a');
    grad.addColorStop(0.8, '#090d16');
    grad.addColorStop(1, '#030508');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    const flare = ctx.createRadialGradient(W * 0.3, H * 0.4, 30, W * 0.3, H * 0.4, 520);
    flare.addColorStop(0, 'rgba(251, 191, 36, 0.36)');
    flare.addColorStop(0.5, 'rgba(217, 119, 6, 0.16)');
    flare.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = flare;
    ctx.fillRect(0, 0, W, H);
  }

  // Light rays / beams
  ctx.save();
  ctx.translate(W * 0.3, H * 0.4);
  ctx.rotate(-0.15);
  for (let i = 0; i < 5; i++) {
    const angle = (i - 2) * 0.16;
    ctx.save();
    ctx.rotate(angle);
    const beam = ctx.createLinearGradient(0, -25, 850, -25);
    beam.addColorStop(0, 'rgba(255, 255, 255, 0.14)');
    beam.addColorStop(0.5, 'rgba(255, 230, 180, 0.05)');
    beam.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = beam;
    ctx.fillRect(0, -35, 850, 70);
    ctx.restore();
  }
  ctx.restore();

  // Floating bokeh specks
  const rng = (seed) => { let s = seed; return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; }; };
  const rand = rng(101);
  for (let i = 0; i < 28; i++) {
    const px = rand() * W, py = rand() * H, pr = 2 + rand() * 10;
    const pAlpha = 0.04 + rand() * 0.15;
    ctx.fillStyle = `rgba(255, 240, 200, ${pAlpha})`;
    ctx.beginPath();
    ctx.arc(px, py, pr, 0, Math.PI * 2);
    ctx.fill();
  }

  // Vignette
  const vignette = ctx.createRadialGradient(W / 2, H / 2, H * 0.36, W / 2, H / 2, W * 0.75);
  vignette.addColorStop(0, 'rgba(0, 0, 0, 0)');
  vignette.addColorStop(1, 'rgba(0, 0, 0, 0.65)');
  ctx.fillStyle = vignette;
  ctx.fillRect(0, 0, W, H);
}

// Enhance user uploaded background image
async function enhanceUserBg(bgPath) {
  try {
    return await sharp(bgPath)
      .rotate()
      .resize(W, H, { fit: 'cover' })
      .modulate({ saturation: 1.15, brightness: 0.96 })
      .png()
      .toBuffer();
  } catch {
    return null;
  }
}

// Fallback photo panel when cutout is unavailable or invalid
async function processPhotoPanel(input, targetH) {
  const actualH = Math.min(targetH, 560);
  const actualW = Math.round(actualH * 0.75);
  const cropped = await sharp(input)
    .rotate()
    .resize(actualW, actualH, { fit: 'cover', position: 'attention' })
    .sharpen({ sigma: 0.8, m1: 1.0, m2: 1.8 })
    .png()
    .toBuffer();

  const mask = Buffer.from(`<svg width="${actualW}" height="${actualH}"><rect width="${actualW}" height="${actualH}" rx="24" fill="#fff"/></svg>`);
  const masked = await sharp(cropped).composite([{ input: mask, blend: 'dest-in' }]).png().toBuffer();
  return { buffer: masked, width: actualW, height: actualH, isCutout: false };
}

// Process subject cutout with trimming, scaling, sharpening, and size validation
async function processSubjectCutout(person, targetH) {
  const isCutout = person.backgroundRemoval;
  const inputBuffer = person.processedBuffer || await fs.readFile(person.path);

  if (isCutout) {
    try {
      const trimmed = await sharp(inputBuffer).trim().png().toBuffer();
      const meta = await sharp(trimmed).metadata();

      // Check if cutout actually has substantial dimensions (avoid pixelated micro-fragments)
      if (!meta.width || !meta.height || meta.width < 100 || meta.height < 100) {
        return await processPhotoPanel(person.path, targetH);
      }

      const actualH = Math.min(targetH, 680);
      const actualW = Math.round((meta.width / meta.height) * actualH);
      const scaled = await sharp(trimmed)
        .resize({ height: actualH })
        .modulate({ saturation: 1.08, brightness: 1.02 })
        .sharpen({ sigma: 1.0, m1: 1.0, m2: 2.0 })
        .png()
        .toBuffer();
      return { buffer: scaled, width: actualW, height: actualH, isCutout: true };
    } catch {
      // Fallback
    }
  }

  return await processPhotoPanel(person.path, targetH);
}

export async function composeVariants({ people, background, title, category = 'Vlog', style = 'Cinematic', emoji = '' }) {
  await fs.mkdir(uploadDir, { recursive: true });
  const n = people.length;

  const processedPeople = [];
  const vision = [];
  for (const person of people) {
    const cutout = await removePersonBackground(person.path);
    const cv = await analyzeFace(person.path);
    const stats = await imageStats(person.path);
    processedPeople.push({ ...person, processedBuffer: cutout.buffer, backgroundRemoval: cutout.removed, backgroundRemovalMethod: cutout.method });
    vision.push({ ...cv, imageQuality: stats.score });
  }

  const bgStats = background?.path ? await imageStats(background.path) : { score: 72, metrics: { brightness: 120, contrast: 55, colorBalance: 75 } };
  const userBgBuffer = background?.path ? await enhanceUserBg(background.path) : null;

  const results = [];

  for (const [i, theme] of themes.entries()) {
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');
    const isHeroRight = theme.mode === 'hero-right' || theme.mode === 'split-screen';

    // 1. Draw Background
    if (userBgBuffer) {
      if (theme.mode === 'split-screen') {
        // Dramatic B&W memory on left, vibrant color on right
        const leftBg = await sharp(userBgBuffer)
          .grayscale()
          .modulate({ brightness: 0.75, contrast: 1.25 })
          .png()
          .toBuffer();
        const leftImg = await loadImage(leftBg);

        const rightBg = await sharp(userBgBuffer)
          .modulate({ saturation: 1.22, brightness: 1.02 })
          .png()
          .toBuffer();
        const rightImg = await loadImage(rightBg);

        ctx.save();
        ctx.beginPath();
        ctx.rect(0, 0, W * 0.46, H);
        ctx.clip();
        ctx.drawImage(leftImg, 0, 0, W, H);
        const leftVignette = ctx.createLinearGradient(0, 0, W * 0.46, 0);
        leftVignette.addColorStop(0, 'rgba(0,0,0,0.65)');
        leftVignette.addColorStop(1, 'rgba(0,0,0,0.2)');
        ctx.fillStyle = leftVignette;
        ctx.fillRect(0, 0, W * 0.46, H);
        ctx.restore();

        ctx.save();
        ctx.beginPath();
        ctx.rect(W * 0.46, 0, W * 0.54, H);
        ctx.clip();
        ctx.drawImage(rightImg, 0, 0, W, H);
        ctx.restore();

        // Glowing seam line
        ctx.save();
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.lineWidth = 2.5;
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.moveTo(W * 0.46, 0);
        ctx.lineTo(W * 0.46, H);
        ctx.stroke();
        ctx.restore();
      } else {
        const bgImg = await loadImage(userBgBuffer);
        ctx.drawImage(bgImg, 0, 0, W, H);

        // Spotlight flare behind subject area
        const subCenterX = isHeroRight ? 950 : 320;
        const flare = ctx.createRadialGradient(subCenterX, 420, 40, subCenterX, 420, 550);
        flare.addColorStop(0, theme.glowColor);
        flare.addColorStop(0.5, 'rgba(0, 0, 0, 0.15)');
        flare.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = flare;
        ctx.fillRect(0, 0, W, H);

        // Contrast gradient behind text area for 100% legibility
        const textX = isHeroRight ? 0 : 520;
        const textW = isHeroRight ? 700 : 760;
        const textBackdrop = ctx.createLinearGradient(textX, 0, textX + textW, 0);
        if (isHeroRight) {
          textBackdrop.addColorStop(0, 'rgba(5, 5, 12, 0.82)');
          textBackdrop.addColorStop(0.65, 'rgba(5, 5, 12, 0.45)');
          textBackdrop.addColorStop(1, 'rgba(5, 5, 12, 0)');
        } else {
          textBackdrop.addColorStop(0, 'rgba(5, 5, 12, 0)');
          textBackdrop.addColorStop(0.35, 'rgba(5, 5, 12, 0.45)');
          textBackdrop.addColorStop(1, 'rgba(5, 5, 12, 0.82)');
        }
        ctx.fillStyle = textBackdrop;
        ctx.fillRect(textX, 0, textW, H);

        // Perimeter vignette
        const vignette = ctx.createRadialGradient(W / 2, H / 2, H * 0.4, W / 2, H / 2, W * 0.75);
        vignette.addColorStop(0, 'rgba(0, 0, 0, 0)');
        vignette.addColorStop(1, 'rgba(0, 0, 0, 0.65)');
        ctx.fillStyle = vignette;
        ctx.fillRect(0, 0, W, H);
      }
    } else {
      renderProceduralBackground(ctx, theme, category, style);
    }

    // 2. Prepare & Position Subjects
    const preparedSubjects = [];
    if (n === 1) {
      const subH = isHeroRight ? 660 : 630;
      const sub = await processSubjectCutout(processedPeople[0], subH);
      const subX = isHeroRight ? W - sub.width - 25 : 40;
      const subY = H - sub.height + 15;
      preparedSubjects.push({ ...sub, x: subX, y: subY, zIndex: 1 });
    } else if (n === 2) {
      const sub0 = await processSubjectCutout(processedPeople[0], 630);
      const sub1 = await processSubjectCutout(processedPeople[1], 510);
      if (isHeroRight) {
        const x0 = W - sub0.width - 25;
        const x1 = Math.max(W - sub0.width - sub1.width * 0.65 - 25, W * 0.48);
        preparedSubjects.push({ ...sub1, x: x1, y: H - sub1.height + 15, zIndex: 1 });
        preparedSubjects.push({ ...sub0, x: x0, y: H - sub0.height + 15, zIndex: 2 });
      } else {
        const x0 = 30;
        const x1 = Math.min(x0 + sub0.width * 0.65, 340);
        preparedSubjects.push({ ...sub1, x: x1, y: H - sub1.height + 15, zIndex: 1 });
        preparedSubjects.push({ ...sub0, x: x0, y: H - sub0.height + 15, zIndex: 2 });
      }
    } else if (n === 3) {
      const sub0 = await processSubjectCutout(processedPeople[0], 600);
      const sub1 = await processSubjectCutout(processedPeople[1], 500);
      const sub2 = await processSubjectCutout(processedPeople[2], 440);
      if (isHeroRight) {
        const x0 = W - sub0.width - 20;
        const x1 = W - sub0.width - sub1.width * 0.55 - 20;
        const x2 = W - sub0.width - sub1.width * 0.55 - sub2.width * 0.55 - 20;
        preparedSubjects.push({ ...sub2, x: x2, y: H - sub2.height + 15, zIndex: 1 });
        preparedSubjects.push({ ...sub1, x: x1, y: H - sub1.height + 15, zIndex: 2 });
        preparedSubjects.push({ ...sub0, x: x0, y: H - sub0.height + 15, zIndex: 3 });
      } else {
        const x0 = 20;
        const x1 = Math.min(x0 + sub0.width * 0.55, 230);
        const x2 = Math.min(x1 + sub1.width * 0.55, 410);
        preparedSubjects.push({ ...sub2, x: x2, y: H - sub2.height + 15, zIndex: 1 });
        preparedSubjects.push({ ...sub1, x: x1, y: H - sub1.height + 15, zIndex: 2 });
        preparedSubjects.push({ ...sub0, x: x0, y: H - sub0.height + 15, zIndex: 3 });
      }
    } else {
      // 4 to 6 subjects: tiered composition
      const halfW = W * 0.48;
      const stepX = Math.max(70, Math.floor((halfW - 120) / (n - 1)));
      for (let p = 0; p < n; p++) {
        const isForeground = p === 0 || p === 1;
        const subH = isForeground ? 520 : 390;
        const sub = await processSubjectCutout(processedPeople[p], subH);
        const subX = isHeroRight
          ? W - 30 - (n - 1 - p) * stepX - sub.width * 0.5
          : 20 + p * stepX;
        const subY = isForeground ? H - sub.height + 15 : H - sub.height - 40;
        preparedSubjects.push({ ...sub, x: subX, y: subY, zIndex: isForeground ? 2 : 1 });
      }
    }

    // Sort by zIndex before rendering
    preparedSubjects.sort((a, b) => a.zIndex - b.zIndex);

    // Draw subjects with rim light and drop shadow
    for (const sub of preparedSubjects) {
      const subImg = await loadImage(sub.buffer);

      // Rim glow
      ctx.save();
      ctx.shadowColor = theme.accent;
      ctx.shadowBlur = sub.isCutout ? 35 : 20;
      ctx.drawImage(subImg, sub.x, sub.y, sub.width, sub.height);
      ctx.restore();

      // Deep drop shadow
      ctx.save();
      ctx.shadowColor = 'rgba(0, 0, 0, 0.9)';
      ctx.shadowBlur = 28;
      ctx.shadowOffsetX = isHeroRight ? -12 : 14;
      ctx.shadowOffsetY = 14;
      ctx.drawImage(subImg, sub.x, sub.y, sub.width, sub.height);
      ctx.restore();

      // Sharp subject foreground
      ctx.drawImage(subImg, sub.x, sub.y, sub.width, sub.height);
    }

    // 3. Render Title & Badges
    const textStartX = isHeroRight ? 60 : 640;
    const lines = wrapText(title, isHeroRight ? 16 : 17, 3);
    const badgeY = 110;
    const badgeText = `${emoji ? String(emoji).trim() + ' ' : ''}${String(category).toUpperCase()} • ${String(style).toUpperCase()}`;

    // Category / Style Pill Badge
    ctx.save();
    ctx.font = 'bold 18px "Segoe UI Emoji", "Nirmala UI", Arial, sans-serif';
    const badgeWidth = Math.min(420, ctx.measureText(badgeText).width + 36);

    ctx.fillStyle = theme.badgeBg;
    ctx.strokeStyle = theme.badgeBorder;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.roundRect(textStartX, badgeY, badgeWidth, 40, 20);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = theme.badgeText;
    ctx.fillText(badgeText, textStartX + 18, badgeY + 26);
    ctx.restore();

    // Render Title typography
    if (theme.banner === 'crimson') {
      // Signature Action Banner (Variant 2 style)
      ctx.save();
      const bannerX = textStartX - 20;
      const bannerY = badgeY + 75;
      ctx.translate(bannerX, bannerY);
      ctx.rotate(-3.5 * Math.PI / 180);

      const bW = Math.min(610, W - textStartX - 20);
      const bH = Math.max(220, lines.length * 85 + 40);

      // Banner shadow
      ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
      ctx.shadowBlur = 25;
      ctx.shadowOffsetX = 6;
      ctx.shadowOffsetY = 12;

      // Banner polygon
      const grad = ctx.createLinearGradient(0, 0, 0, bH);
      grad.addColorStop(0, '#b91c1c');
      grad.addColorStop(0.6, '#991b1b');
      grad.addColorStop(1, '#450a0a');
      ctx.fillStyle = grad;

      ctx.beginPath();
      ctx.moveTo(18, 0);
      ctx.lineTo(bW, 0);
      ctx.lineTo(bW - 24, bH);
      ctx.lineTo(-8, bH);
      ctx.closePath();
      ctx.fill();

      // Gold border
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Top interior line
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(28, 8);
      ctx.lineTo(bW - 8, 8);
      ctx.stroke();

      // Lines inside banner
      ctx.font = '900 68px "Nirmala UI", "Arial Black", Impact, sans-serif';
      ctx.lineJoin = 'round';

      lines.forEach((line, idx) => {
        const lineY = 75 + idx * 80;
        ctx.lineWidth = 16;
        ctx.strokeStyle = '#000000';
        ctx.strokeText(line, 45, lineY);

        const textGrad = ctx.createLinearGradient(45, lineY - 55, 45, lineY);
        if (idx === 0) {
          textGrad.addColorStop(0, '#fffbeb');
          textGrad.addColorStop(0.4, '#fef08a');
          textGrad.addColorStop(1, '#facc15');
        } else {
          textGrad.addColorStop(0, '#ffffff');
          textGrad.addColorStop(1, '#f1f5f9');
        }
        ctx.fillStyle = textGrad;
        ctx.fillText(line, 45, lineY);
      });

      ctx.restore();
    } else if (theme.banner === 'glass-cyan' || theme.banner === 'glass-dark') {
      // Modern Glass Card Plate
      const cardX = textStartX - 15;
      const cardY = badgeY + 70;
      const cardW = Math.min(590, W - textStartX - 25);
      const cardH = lines.length * 90 + 40;

      ctx.save();
      ctx.fillStyle = theme.banner === 'glass-cyan' ? 'rgba(8, 20, 36, 0.78)' : 'rgba(15, 23, 42, 0.82)';
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 2.5;
      ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
      ctx.shadowBlur = 20;
      ctx.beginPath();
      ctx.roundRect(cardX, cardY, cardW, cardH, 20);
      ctx.fill();
      ctx.stroke();
      ctx.restore();

      ctx.save();
      const fontSize = lines.length >= 3 ? 58 : 70;
      ctx.font = `900 ${fontSize}px "Nirmala UI", "Arial Black", Impact, sans-serif`;
      ctx.lineJoin = 'round';

      lines.forEach((line, idx) => {
        const lineY = cardY + 75 + idx * (fontSize + 18);
        ctx.lineWidth = 16;
        ctx.strokeStyle = '#000000';
        ctx.strokeText(line, textStartX + 15, lineY);

        const textGrad = ctx.createLinearGradient(textStartX, lineY - fontSize, textStartX, lineY);
        const colors = idx === 0 ? theme.textColor1 : theme.textColor2;
        textGrad.addColorStop(0, colors[0]);
        textGrad.addColorStop(1, colors[1]);
        ctx.fillStyle = textGrad;
        ctx.fillText(line, textStartX + 15, lineY);
      });
      ctx.restore();
    } else {
      // Floating 3D Title with Multi-Layer Stroke and Deep Shadow
      ctx.save();
      const fontSize = lines.length >= 3 ? 64 : 76;
      ctx.font = `900 ${fontSize}px "Nirmala UI", "Arial Black", Impact, sans-serif`;
      ctx.lineJoin = 'round';

      const startY = badgeY + 110;
      lines.forEach((line, idx) => {
        const lineY = startY + idx * (fontSize + 20);

        // 3D Shadow Extrusion
        ctx.fillStyle = 'rgba(0, 0, 0, 0.95)';
        ctx.fillText(line, textStartX + 5, lineY + 7);

        // Heavy dark outline
        ctx.lineWidth = 18;
        ctx.strokeStyle = '#000000';
        ctx.strokeText(line, textStartX, lineY);

        // Gradient Fill
        const textGrad = ctx.createLinearGradient(textStartX, lineY - fontSize, textStartX, lineY);
        const colors = idx === 0 ? theme.textColor1 : theme.textColor2;
        textGrad.addColorStop(0, colors[0]);
        textGrad.addColorStop(1, colors[1]);
        ctx.fillStyle = textGrad;
        ctx.fillText(line, textStartX, lineY);
      });
      ctx.restore();
    }

    const filename = `${crypto.randomUUID()}.png`;
    const finalBuffer = canvas.toBuffer('image/png');
    await fs.writeFile(path.join(uploadDir, filename), finalBuffer);

    // Seven-factor composite ranking
    const titleLength = Array.from(String(title || '').trim()).length;
    const titleReadability = Math.max(35, Math.min(100, 100 - Math.max(0, titleLength - 22) * 1.5));
    const faceAttention = Math.round(100 * vision.reduce((sum, v) => sum + v.attention, 0) / Math.max(1, vision.length));
    const subjectProminence = n === 1 ? 96 : n <= 3 ? 88 : n <= 5 ? 78 : 68;
    const backgroundQuality = Math.max(40, Math.min(100, bgStats.score));
    const contrast = Math.max(45, Math.min(100, Math.round(60 + Math.abs(127 - (bgStats.metrics.brightness || 120)) * 0.25)));
    const composition = [94, 92, 89, 87, 85, 91, 88, 86, 84, 82][i];
    const visualBalance = [92, 90, 88, 86, 89, 85, 87, 83, 81, 84][i];
    const factors = { faceAttention, titleReadability, visualBalance, subjectProminence, backgroundQuality, composition, contrast };
    const weights = { faceAttention: .18, titleReadability: .20, visualBalance: .14, subjectProminence: .16, backgroundQuality: .10, composition: .12, contrast: .10 };
    const score = Math.round(Object.entries(factors).reduce((sum, [key, value]) => sum + value * weights[key], 0));

    results.push({
      url: `/uploads/${filename}`,
      score,
      label: theme.name,
      layout: theme.mode,
      scoreType: 'seven-factor heuristic composition score; not measured CTR',
      factors,
      vision: {
        backgroundRemoval: processedPeople.map(p => p.backgroundRemoval),
        faceAnalysis: vision.map(v => ({ detected: v.detected, count: v.count, method: v.method }))
      }
    });
  }

  return results.sort((a, b) => b.score - a.score).slice(0, 5).map((item, index) => ({ ...item, rank: index + 1 }));
}
