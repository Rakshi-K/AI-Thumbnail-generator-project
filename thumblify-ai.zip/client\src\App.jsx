import React, { useEffect, useState, useRef } from 'react';
import {
  Sparkles, LayoutDashboard, WandSparkles, ScanSearch, FlaskConical,
  FolderOpen, Settings as SettingsIcon, Bell, Search, Plus, ArrowUpRight,
  Image as ImageIcon, Download, Trash2, LogOut, Menu, X, ChevronRight,
  ShieldCheck, Zap, Languages, UploadCloud, CheckCircle2,
  AlertCircle, LoaderCircle, Eye, History, BarChart3, Edit3,
  Layers, Sliders, Palette, MonitorPlay, Smartphone, Laptop, Sun,
  Moon, PlaySquare, AlertTriangle, Check, Swords, Package, Sticker,
  Crop, Scale, RotateCw, Copy, Award, Tag, Printer, Flame
} from 'lucide-react';
import { api, assetUrl, getToken } from './api';

const nav = [
  ['Dashboard', LayoutDashboard],
  ['Generate Thumbnail', WandSparkles],
  ['My Generations', History],
  ['Thumbnail Analyzer', ScanSearch],
  ['A/B Battle', Swords],
  ['Editor', Edit3],
  ['Analytics', BarChart3],
  ['Templates', Layers],
  ['Projects', FolderOpen],
  ['Prompt Studio', FlaskConical],
  ['Settings', SettingsIcon]
];

const categories = ['Vlog', 'Kannada Serial', 'News', 'Gaming', 'Comedy', 'Cooking', 'Devotional', 'Education'];

export default function App() {
  const [token, setToken] = useState(getToken());
  const [user, setUser] = useState(null);
  const [authMode, setAuthMode] = useState('login');
  const [authForm, setAuthForm] = useState({ name: '', email: '', password: '' });
  const [page, setPage] = useState('Dashboard');
  const [mobileNav, setMobileNav] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  // Data states
  const [projects, setProjects] = useState([]);
  const [generations, setGenerations] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [templates, setTemplates] = useState([]);
  const [simData, setSimData] = useState(null);
  const [multiFormatData, setMultiFormatData] = useState(null);
  const [abBattleData, setAbBattleData] = useState(null);
  const [auditCertData, setAuditCertData] = useState(null);

  // Generator form
  const [title, setTitle] = useState('ನಿಮಗೆ ಗೊತ್ತಾ? Amazing Facts');
  const [language, setLanguage] = useState('Kannada');
  const [category, setCategory] = useState('Vlog');
  const [style, setStyle] = useState('Cinematic');
  const [emoji, setEmoji] = useState('🔥');
  const [people, setPeople] = useState([]);
  const [background, setBackground] = useState(null);
  const [useAiBg, setUseAiBg] = useState(true);
  const [enhanceFaces, setEnhanceFaces] = useState(true);
  const [addTextEffects, setAddTextEffects] = useState(true);
  const [variants, setVariants] = useState([]);
  const [selected, setSelected] = useState(0);

  // Analyzer
  const [analyzeFile, setAnalyzeFile] = useState(null);
  const [analysis, setAnalysis] = useState(null);

  // Prompt Studio
  const [prompt, setPrompt] = useState('A cinematic Kannada YouTube thumbnail about amazing facts, expressive host, dramatic lighting');
  const [refined, setRefined] = useState('');

  // Editor target
  const [editorImage, setEditorImage] = useState(null);
  const [editorTitle, setEditorTitle] = useState('ನಿಮಗೆ ಗೊತ್ತಾ?');

  useEffect(() => {
    if (token) {
      api('/auth/me').then(d => {
        setUser(d.user);
        loadProjects();
      }).catch(() => {
        localStorage.removeItem('thumblify_token');
        setToken(null);
      });
    }
  }, [token]);

  useEffect(() => {
    if (!token) return;
    if (page === 'My Generations') api('/thumbnails/history').then(d => setGenerations(d.generations || [])).catch(e => setError(e.message));
    if (page === 'Analytics') api('/thumbnails/analytics').then(setAnalytics).catch(e => setError(e.message));
    if (page === 'Templates') api('/templates').then(d => setTemplates(d.templates || [])).catch(e => setError(e.message));
  }, [page, token]);

  async function loadProjects() {
    try {
      const d = await api('/projects');
      setProjects(d.projects || []);
    } catch (e) {
      setError(e.message);
    }
  }

  async function submitAuth(e) {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const d = await api(`/auth/${authMode}`, { method: 'POST', body: JSON.stringify(authForm) });
      localStorage.setItem('thumblify_token', d.token);
      setToken(d.token);
      setUser(d.user);
      setNotice('Welcome to Thumblify AI');
      await loadProjects();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  function logout() {
    localStorage.removeItem('thumblify_token');
    setToken(null);
    setUser(null);
    setProjects([]);
    setVariants([]);
  }

  async function generate(e) {
    e.preventDefault(); setLoading(true); setError(''); setNotice('Composing ten candidate layouts and ranking top 5…');
    try {
      const fd = new FormData();
      fd.append('title', title);
      fd.append('language', language);
      fd.append('category', category);
      fd.append('style', style);
      fd.append('emoji', emoji);
      people.forEach(p => fd.append('people', p));
      if (background) fd.append('background', background);
      const d = await api('/thumbnails/generate', { method: 'POST', body: fd });
      setVariants(d.variants || []);
      setSelected(0);
      if (typeof d.creditsRemaining === 'number') {
        setUser(current => current ? ({ ...current, credits: d.creditsRemaining }) : current);
      }
      setNotice('Five studio-grade thumbnail concepts ready! ' + (d.note || ''));
      await saveProject(d.variants || []);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function saveProject(items = variants) {
    if (!items.length) return;
    try {
      await api('/projects', {
        method: 'POST',
        body: JSON.stringify({
          title: title.slice(0, 150) || 'Untitled thumbnail',
          language,
          category,
          thumbnails: items.map(v => ({ url: v.url, score: v.score, label: v.label }))
        })
      });
      await loadProjects();
    } catch (e) {
      console.warn('Auto-save error:', e.message);
    }
  }

  async function runAnalysis(e) {
    e.preventDefault();
    if (!analyzeFile) return setError('Choose an image first.');
    setLoading(true); setError(''); setAnalysis(null);
    try {
      const fd = new FormData();
      fd.append('image', analyzeFile);
      setAnalysis(await api('/analyzer/analyze', { method: 'POST', body: fd }));
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function runPrompt(e) {
    e.preventDefault(); setLoading(true); setError('');
    try {
      const d = await api('/prompt/refine', { method: 'POST', body: JSON.stringify({ prompt, language }) });
      setRefined(d.refinedPrompt);
      setNotice(d.note || `Prompt refined using ${d.mode}.`);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  function download(url, label = 'thumblify-thumbnail') {
    const a = document.createElement('a');
    a.href = assetUrl(url);
    a.download = `${label.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.png`;
    a.target = '_blank';
    a.rel = 'noreferrer';
    a.click();
  }

  function openInEditor(url, lbl) {
    setEditorImage(assetUrl(url));
    setEditorTitle(title || lbl || 'ನಿಮಗೆ ಗೊತ್ತಾ?');
    setPage('Editor');
  }

  function applyTemplate(tmpl) {
    setTitle(tmpl.title);
    setCategory(tmpl.category);
    setLanguage(tmpl.language);
    setStyle(tmpl.style);
    setEmoji(tmpl.emoji);
    setPage('Generate Thumbnail');
    setNotice(`Loaded "${tmpl.title}" template.`);
  }

  function openSimulator(item, customTitle) {
    if (!item) return;
    const itemUrl = typeof item === 'string' ? item : (item.url || item.imageUrl);
    setSimData({
      imageUrl: itemUrl,
      title: customTitle || item.title || title || 'YouTube Video Title',
      category: item.category || category || 'Vlog',
      variants: variants.length ? variants : (item.variants || [{ url: itemUrl, label: 'Render' }]),
      channelName: user?.brandKit?.channelName || user?.name || 'Creator Studio'
    });
  }

  function openMultiFormat(item, customTitle) {
    if (!item) return;
    const itemUrl = typeof item === 'string' ? item : (item.url || item.imageUrl);
    setMultiFormatData({
      imageUrl: itemUrl,
      title: customTitle || item.title || title || 'Creator Pack'
    });
  }

  function openAbBattle(variantA, variantB) {
    const list = variants.length ? variants : generations.flatMap(g => g.variants || []);
    setAbBattleData({
      variantA: variantA || list[0] || null,
      variantB: variantB || list[1] || list[0] || null,
      allVariants: list
    });
  }

  function openAuditCert(item, customTitle, extra = {}) {
    if (!item) return;
    setAuditCertData({
      variant: item,
      title: customTitle || item.title || title || 'YouTube Thumbnail',
      category: extra.category || category || 'Vlog',
      language: extra.language || language || 'Kannada',
      ...extra
    });
  }

  if (!token || !user) {
    return <AuthScreen mode={authMode} setMode={setAuthMode} form={authForm} setForm={setAuthForm} submit={submitAuth} loading={loading} error={error} />;
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? 'show' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Sparkles size={21} /></div>
          <div><b>thumblify<span>.ai</span></b><small>CREATOR STUDIO</small></div>
          <button className="icon-btn close-nav" onClick={() => setMobileNav(false)}><X size={18} /></button>
        </div>

        <div className="workspace">
          <div className="workspace-icon">T</div>
          <div><b>My Workspace</b><small>{user.credits ?? 20} generation credits</small></div>
          <ChevronRight size={15} />
        </div>

        <div className="nav-label">WORKSPACE</div>
        <nav>
          {nav.map(([label, Icon]) => (
            <button
              key={label}
              className={`nav-item ${page === label ? 'active' : ''}`}
              onClick={() => { setPage(label); setMobileNav(false); setError(''); setNotice(''); }}
            >
              <Icon size={17} />
              <span>{label}</span>
              {label === 'Generate Thumbnail' && <span className="nav-new">AI</span>}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="upgrade-card">
            <div className="upgrade-icon"><Sparkles size={16} /></div>
            <b>Creator Studio</b>
            <p>10-candidate layout ranking & canvas editor</p>
            <button onClick={() => setPage('Generate Thumbnail')}>New Thumbnail <ArrowUpRight size={13} /></button>
          </div>

          <div className="user-row">
            <div className="avatar">{user.name?.[0]?.toUpperCase() || 'U'}</div>
            <div className="user-details"><b>{user.name}</b><small>{user.email}</small></div>
            <button title="Sign out" className="icon-btn" onClick={logout}><LogOut size={16} /></button>
          </div>
        </div>
      </aside>

      {mobileNav && <div className="scrim" onClick={() => setMobileNav(false)} />}

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-btn mobile-menu" onClick={() => setMobileNav(true)}><Menu size={20} /></button>
            <span className="breadcrumb">Studio</span>
            <ChevronRight size={15} />
            <b>{page}</b>
          </div>
          <div className="topbar-right">
            <div className="search-box">
              <Search size={16} />
              <input placeholder="Search thumbnails..." onKeyDown={e => { if (e.key === 'Enter') setPage('Projects'); }} />
            </div>
            <button className="icon-btn notification" onClick={() => setNotice('All systems operational!')}><Bell size={18} /><i /></button>
            <div className="avatar">{user.name?.[0]?.toUpperCase() || 'U'}</div>
          </div>
        </header>

        <div className="page-content">
          {error && <div className="alert error"><AlertCircle size={17} /><span>{error}</span><button onClick={() => setError('')}><X size={15} /></button></div>}
          {notice && <div className="alert success"><CheckCircle2 size={17} /><span>{notice}</span><button onClick={() => setNotice('')}><X size={15} /></button></div>}

          {page === 'Dashboard' && (
            <Dashboard
              user={user}
              projects={projects}
              setPage={setPage}
            />
          )}

          {page === 'Generate Thumbnail' && (
            <Generator
              {...{
                title, setTitle, language, setLanguage, category, setCategory, style, setStyle, emoji, setEmoji,
                people, setPeople, background, setBackground, useAiBg, setUseAiBg, enhanceFaces, setEnhanceFaces,
                addTextEffects, setAddTextEffects, variants, selected, setSelected, generate, loading, download,
                openInEditor, openSimulator, openMultiFormat, openAbBattle, openAuditCert, setNotice
              }}
            />
          )}

          {page === 'My Generations' && (
            <Generations
              generations={generations}
              download={download}
              openInEditor={openInEditor}
              setPage={setPage}
              openSimulator={openSimulator}
              openMultiFormat={openMultiFormat}
              openAbBattle={openAbBattle}
              openAuditCert={openAuditCert}
            />
          )}

          {page === 'Thumbnail Analyzer' && (
            <Analyzer
              {...{ analyzeFile, setAnalyzeFile, analysis, runAnalysis, loading, openSimulator }}
            />
          )}

          {page === 'A/B Battle' && (
            <AbBattlePage
              variants={variants.length ? variants : generations.flatMap(g => g.variants || [])}
              title={title}
              openSimulator={openSimulator}
              setPage={setPage}
            />
          )}

          {page === 'Editor' && (
            <Editor
              initialImage={editorImage}
              initialTitle={editorTitle}
              setNotice={setNotice}
              setPage={setPage}
              openSimulator={openSimulator}
              openMultiFormat={openMultiFormat}
            />
          )}

          {page === 'Analytics' && (
            <Analytics analytics={analytics} />
          )}

          {page === 'Templates' && (
            <Templates
              templates={templates}
              applyTemplate={applyTemplate}
            />
          )}

          {page === 'Projects' && (
            <Projects
              projects={projects}
              deleteProject={async id => {
                try { await api(`/projects/${id}`, { method: 'DELETE' }); await loadProjects(); } catch (e) { setError(e.message); }
              }}
              setPage={setPage}
              download={download}
              openSimulator={openSimulator}
            />
          )}

          {page === 'Prompt Studio' && (
            <PromptStudio
              {...{ prompt, setPrompt, language, runPrompt, refined, setRefined, loading, setTitle, setPage }}
            />
          )}

          {page === 'Settings' && (
            <SettingsPage
              user={user}
              setUser={setUser}
              setNotice={setNotice}
              setError={setError}
            />
          )}
        </div>

        <footer>
          <span>© 2026 Thumblify AI Creator Studio</span>
          <span><ShieldCheck size={14} /> Multi-Candidate AI Thumbnail Architecture</span>
          <span>High-CTR Multi-Language Thumbnail Generation & Analysis</span>
        </footer>
      </main>

      {simData && <YouTubeSimulator data={simData} onClose={() => setSimData(null)} />}
      {multiFormatData && <MultiFormatModal data={multiFormatData} onClose={() => setMultiFormatData(null)} />}
      {abBattleData && <AbBattleArena data={abBattleData} onClose={() => setAbBattleData(null)} openSimulator={openSimulator} />}
      {auditCertData && <AuditCertificateModal data={auditCertData} onClose={() => setAuditCertData(null)} />}
    </div>
  );
}

// -------------------------------------------------------------
// PAGE: Dashboard
// -------------------------------------------------------------
function Dashboard({ user, projects, setPage }) {
  return (
    <>
      <div className="welcome-banner">
        <div className="welcome-glow" />
        <div className="welcome-content">
          <div className="eyebrow"><Sparkles size={14} /> AI-POWERED PLATFORM</div>
          <h1>Ideas into <span>impact.</span></h1>
          <p>Automated YouTube thumbnail generation, multi-candidate layout ranking, and visual quality analysis.</p>
          <div className="welcome-actions">
            <button className="btn primary" onClick={() => setPage('Generate Thumbnail')}>
              <WandSparkles size={17} /> Generate Thumbnail <ArrowUpRight size={15} />
            </button>
            <button className="btn secondary" onClick={() => setPage('Thumbnail Analyzer')}>
              <ScanSearch size={16} /> Audit Thumbnail
            </button>
          </div>
        </div>
        <div className="banner-art">
          <div className="art-card art-back"><div className="art-shape" /></div>
          <div className="art-card art-front">
            <div className="art-chip">CREATOR STUDIO</div>
            <div className="art-headline">THUMBLIFY<br /><span>AI STUDIO</span></div>
            <div className="art-sub">7-FACTOR RANKING</div>
            <div className="art-score"><Sparkles size={13} /> 94 QUALITY SCORE</div>
          </div>
          <div className="floating-star star-one">✦</div>
          <div className="floating-star star-two">✧</div>
        </div>
      </div>

      <div className="section-head">
        <div><h2>Creator metrics</h2><p>Generation analytics and workspace telemetry</p></div>
        <button className="text-btn" onClick={() => setPage('Projects')}>View projects <ArrowUpRight size={15} /></button>
      </div>

      <div className="stats-grid">
        <Stat icon={ImageIcon} label="Saved projects" value={projects.length} hint="Your creative library" />
        <Stat icon={Sparkles} label="AI concepts" value={projects.reduce((n, p) => n + (p.thumbnails?.length || 0), 0)} hint="Across saved runs" />
        <Stat icon={Languages} label="Bilingual support" value="Kannada & English" hint="Native script typesetting" />
        <Stat icon={Zap} label="Available credits" value={user.credits ?? 20} hint="Generation quota" />
      </div>

      <div className="section-head">
        <div><h2>Platform core modules</h2><p>High-CTR layout composition, typography, and AI ranking</p></div>
      </div>

      <div className="tool-grid">
        <ToolCard icon={WandSparkles} color="purple" title="Thumbnail Generator" desc="Compose 10 layout candidates and rank top-5 using 7-factor composite scoring." action="Generate" onClick={() => setPage('Generate Thumbnail')} />
        <ToolCard icon={ScanSearch} color="cyan" title="Thumbnail Analyzer" desc="6-dimensional no-reference image quality audit (brightness, contrast, 16:9 compliance)." action="Audit image" onClick={() => setPage('Thumbnail Analyzer')} />
        <ToolCard icon={Edit3} color="pink" title="Thumbnail Editor" desc="Interactive post-generation canvas editor to fine-tune typography, colors, and badges." action="Open editor" onClick={() => setPage('Editor')} />
        <ToolCard icon={Layers} color="gold" title="Thumbnail Templates" desc="Pre-curated viral formats for Kannada Serial, Vlog, Gaming, News, and Comedy." action="Explore templates" onClick={() => setPage('Templates')} />
        <ToolCard icon={BarChart3} color="green" title="CTR Analytics" desc="Review generation volume, category telemetry, and average heuristic scores." action="View analytics" onClick={() => setPage('Analytics')} />
        <ToolCard icon={FlaskConical} color="purple" title="Prompt Studio" desc="AI prompt engineering workspace to structure production-ready creator briefs." action="Refine prompt" onClick={() => setPage('Prompt Studio')} />
      </div>
    </>
  );
}

// -------------------------------------------------------------
// PAGE: Generate Thumbnail
// -------------------------------------------------------------
function Generator(p) {
  const [showSafeZone, setShowSafeZone] = useState(false);
  const [showHeatmap, setShowHeatmap] = useState(false);
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">AI CREATION & RANKING PIPELINE</div>
          <h1>Generate Thumbnails</h1>
          <p>Upload 2–6 person photos, choose a title and style, and let the 10-candidate ranking engine compose the top 5 renders.</p>
        </div>
        <div className="engine-pill"><span /> 7-FACTOR ENGINE READY</div>
      </div>

      <div className="generator-layout">
        <form className="panel generator-form" onSubmit={p.generate}>
          <div className="panel-title">
            <div className="step-num">01</div>
            <div>
              <h3>Upload & brief</h3>
              <p>Supply your subjects, title, and visual direction.</p>
            </div>
          </div>

          <div className="viral-hooks-box">
            <div className="viral-hooks-header">
              <span><Sparkles size={13} /> Viral Hook Quick-Chips (1-Click Insert)</span>
              <button
                type="button"
                className="text-btn sm"
                style={{ fontSize: '10px' }}
                onClick={() => p.setLanguage(l => l === 'Kannada' ? 'English' : 'Kannada')}
              >
                Switch to {p.language === 'Kannada' ? 'English' : 'Kannada'} Hooks
              </button>
            </div>
            <div className="viral-hooks-scroll">
              {(p.language === 'Kannada' ? [
                '🔥 ನಿಮಗೆ ಗೊತ್ತಾ?', '⚡ ಶಾಕಿಂಗ್ ಸತ್ಯ!', '👀 ನೋಡಲೇಬೇಕಾದ ವಿಡಿಯೋ',
                '🤯 ಇದು ಹೇಗೆ ಸಾಧ್ಯ?', '🚀 ಹೊಸ ಅಪ್‌ಡೇಟ್ 2026', '💡 ಸಂಪೂರ್ಣ ಮಾಹಿತಿ',
                '🏆 ನಂಬರ್ 1 ರಹಸ್ಯ', '⚠️ ಮಿಸ್ ಮಾಡ್ಕೋಬೇಡಿ!'
              ] : [
                '🔥 Did You Know?', '⚡ Shocking Truth!', "👀 Don't Buy Yet!",
                '🤯 Unbelievable!', '🚀 Huge Mistake!', '💡 Top 5 Secrets',
                '🏆 Must Watch Video', "⚠️ Before It's Too Late!"
              ]).map(hook => (
                <button
                  key={hook}
                  type="button"
                  className="viral-hook-chip"
                  onClick={() => {
                    const cleanHook = hook.replace(/^[\p{Emoji}\s]+/gu, '').trim();
                    if (!p.title || p.title === 'ನಿಮಗೆ ಗೊತ್ತಾ? Amazing Facts') {
                      p.setTitle(hook + ' ');
                    } else if (!p.title.includes(cleanHook)) {
                      p.setTitle(hook + ' ' + p.title);
                    }
                  }}
                >
                  {hook}
                </button>
              ))}
            </div>
          </div>

          <label>
            Thumbnail Title <span className="label-meta">{p.title.length}/140</span>
            <textarea
              required
              maxLength="140"
              rows="2"
              value={p.title}
              onChange={e => p.setTitle(e.target.value)}
              placeholder="e.g. ನಿಮಗೆ ಗೊತ್ತಾ? Amazing Facts"
            />
          </label>

          <div className="two-col">
            <label>
              Language
              <select value={p.language} onChange={e => p.setLanguage(e.target.value)}>
                <option>Kannada</option>
                <option>English</option>
              </select>
            </label>
            <label>
              Category
              <select value={p.category} onChange={e => p.setCategory(e.target.value)}>
                {categories.map(c => <option key={c}>{c}</option>)}
              </select>
            </label>
          </div>

          <div className="two-col">
            <label>
              Visual Direction
              <select value={p.style} onChange={e => p.setStyle(e.target.value)}>
                <option>Cinematic</option>
                <option>Bold & vibrant</option>
                <option>Minimal</option>
                <option>News editorial</option>
                <option>Devotional glow</option>
              </select>
            </label>
            <label>
              Optional Emoji
              <input value={p.emoji} maxLength="8" onChange={e => p.setEmoji(e.target.value)} placeholder="🔥 ⚡ 🚨" />
            </label>
          </div>

          <div className="field-block">
            <div className="field-head">
              <label>Person Photos (2–6 recommended) <span className="required">*</span></label>
              <span className="label-meta">{p.people.length}/6 added</span>
            </div>
            <label className="upload-zone">
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                multiple
                onChange={e => p.setPeople(Array.from(e.target.files || []).slice(0, 6))}
              />
              <div className="upload-icon"><UploadCloud size={22} /></div>
              <b>Drop 2–6 person photos here</b>
              <span>or click to browse • PNG, JPG or WebP</span>
              <small>Cutout engine automatically isolates each person.</small>
            </label>
            {p.people.length > 0 && (
              <div className="file-pills">
                {p.people.map((f, i) => (
                  <span key={`${f.name}-${i}`}>
                    {f.name}
                    <button type="button" onClick={() => p.setPeople(p.people.filter((_, j) => i !== j))}><X size={12} /></button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="field-block">
            <div className="field-head">
              <label>Background Image <span className="optional">(optional)</span></label>
            </div>
            <label className="upload-zone compact">
              <input
                type="file"
                accept="image/png,image/jpeg,image/webp"
                onChange={e => p.setBackground(e.target.files?.[0] || null)}
              />
              <ImageIcon size={18} />
              <span>{p.background ? p.background.name : 'Upload background or leave empty for AI procedural lighting'}</span>
            </label>
          </div>

          <div className="two-col" style={{ fontSize: '11px', color: '#b6adc9' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <input type="checkbox" checked={p.useAiBg} onChange={e => p.setUseAiBg(e.target.checked)} />
              Use AI Procedural Lighting
            </label>
            <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
              <input type="checkbox" checked={p.enhanceFaces} onChange={e => p.setEnhanceFaces(e.target.checked)} />
              Enhance Subject Rim Light
            </label>
          </div>

          <button className="btn primary wide" disabled={p.loading || p.people.length < 1}>
            {p.loading ? <LoaderCircle className="spin" size={17} /> : <WandSparkles size={17} />}
            Generate 5 Ranked Concepts <ArrowUpRight size={16} />
          </button>

          <div className="form-foot">
            <span><CheckCircle2 size={13} /> 1280 × 720 (16:9) Output</span>
            <span><CheckCircle2 size={13} /> 7-Factor Composite Ranking</span>
          </div>
        </form>

        <div className="results-column">
          <div className="panel results-panel">
            <div className="results-head">
              <div>
                <div className="eyebrow">RANKED ALTERNATIVES</div>
                <h2>{p.variants.length ? 'Top 5 Layout Renders' : 'Your results will appear here'}</h2>
              </div>
              <span className="count-pill">{p.variants.length} / 5 Selected</span>
            </div>

            {p.variants.length ? (
              <>
                <div className="variant-grid">
                  {p.variants.map((v, i) => (
                    <div key={v.url} className={`variant-card ${p.selected === i ? 'chosen' : ''}`}>
                      <div className="variant-img-wrap" onClick={() => p.setSelected(i)}>
                        <img src={assetUrl(v.url)} alt={v.label} />
                        <span className={`rank-badge ${i === 0 ? 'best' : ''}`}>
                          {i === 0 ? '★ #1 BEST' : `#${v.rank || i + 1}`}
                        </span>
                        <span className="variant-score">{v.score}<small>/100</small></span>
                      </div>
                      <div className="variant-info">
                        <b>{v.label}</b>
                        <small>{v.layout}</small>
                      </div>
                      <div className="variant-actions">
                        <button onClick={() => p.setSelected(i)} title="Preview"><Eye size={12} /> Preview</button>
                        <button onClick={() => p.openSimulator(v, p.title)} title="YouTube Simulator"><MonitorPlay size={12} /> Feed</button>
                        <button onClick={() => p.openMultiFormat(v, p.title)} title="Creator Pack (16:9, 9:16, 1:1)"><Package size={12} /> Pack</button>
                        <button onClick={() => p.openAbBattle(v, p.variants[(i + 1) % p.variants.length])} title="A/B Battle"><Swords size={12} /> A/B</button>
                        <button onClick={() => p.openInEditor(v.url, v.label)} title="Edit in Canvas"><Edit3 size={12} /> Edit</button>
                        <button onClick={() => p.download(v.url, v.label)} title="Download PNG"><Download size={12} /> Export</button>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="selected-preview">
                  <div className="preview-title">
                    <div>
                      <span className="eyebrow">SELECTED CANDIDATE</span>
                      <h3>{p.variants[p.selected]?.label}</h3>
                    </div>
                    <div className="score-big">{p.variants[p.selected]?.score}<small>/100</small></div>
                  </div>

                  <div className="preview-toolbar">
                    <label className="sim-toggle">
                      <input
                        type="checkbox"
                        checked={showSafeZone}
                        onChange={e => setShowSafeZone(e.target.checked)}
                      />
                      <span>🛡️ Safe Area & Duration Badge</span>
                    </label>
                    <label className="sim-toggle">
                      <input
                        type="checkbox"
                        checked={showHeatmap}
                        onChange={e => setShowHeatmap(e.target.checked)}
                      />
                      <span>🔥 Attention Gaze Heatmap</span>
                    </label>
                    <button
                      type="button"
                      className="btn accent sm"
                      onClick={() => p.openSimulator(p.variants[p.selected], p.title)}
                    >
                      <MonitorPlay size={14} /> Preview in YouTube Feed
                    </button>
                  </div>

                  <div className="preview-thumb-container">
                    <img className="large-preview" src={assetUrl(p.variants[p.selected]?.url)} alt="Thumbnail preview" />
                    {showSafeZone && (
                      <div className="preview-safe-overlay">
                        <div className="preview-safe-margins" />
                        <div className="preview-safe-deadzone">
                          YT DEAD ZONE
                        </div>
                        <span className="preview-safe-timestamp">14:28</span>
                      </div>
                    )}
                    {showHeatmap && (
                      <div className="heatmap-overlay">
                        <div className="heatmap-marker" style={{ top: '22%', left: '26%' }}>🔥 95% Eye Fixation</div>
                        <div className="heatmap-marker" style={{ top: '62%', left: '55%' }}>⚡ 89% Title Attention</div>
                      </div>
                    )}
                  </div>

                  {showHeatmap && (
                    <div className="heatmap-legend">
                      <span style={{ fontWeight: 700, color: '#fca5a5' }}>Simulated Eye-Tracking:</span>
                      <div className="heatmap-gradient-bar" />
                      <span style={{ color: '#9d94b4' }}>Cold (Low Attention) → Hot (First 400ms Gaze Fixation)</span>
                    </div>
                  )}

                  {showSafeZone && (
                    <div className={`safe-zone-advisory ${p.variants[p.selected]?.layout?.toLowerCase().includes('right') ? '' : 'safe'}`}>
                      <AlertTriangle size={15} />
                      <span>
                        <strong>Safety Analysis:</strong> YouTube duration badge permanently overlays the bottom-right rectangle ($x \ge 80\%, y \ge 78\%$) across mobile and desktop. {p.variants[p.selected]?.layout?.toLowerCase().includes('right') ? '⚠️ Caution: Right-side elements may overlap with the timestamp badge.' : '✅ Main title and subject elements are placed safely outside the timestamp dead-zone.'}
                      </span>
                    </div>
                  )}

                  {p.variants[p.selected]?.factors && (
                    <div className="factor-breakdown">
                      <div className="factor-chip"><small>Face Attention</small><strong>{p.variants[p.selected].factors.faceAttention}%</strong></div>
                      <div className="factor-chip"><small>Title Readability</small><strong>{p.variants[p.selected].factors.titleReadability}%</strong></div>
                      <div className="factor-chip"><small>Visual Balance</small><strong>{p.variants[p.selected].factors.visualBalance}%</strong></div>
                      <div className="factor-chip"><small>Prominence</small><strong>{p.variants[p.selected].factors.subjectProminence}%</strong></div>
                    </div>
                  )}

                  <div className="preview-btns">
                    <button className="btn accent" onClick={() => p.openSimulator(p.variants[p.selected], p.title)}>
                      <MonitorPlay size={16} /> Preview in YouTube Feed
                    </button>
                    <button className="btn secondary" onClick={() => p.openAuditCert(p.variants[p.selected], p.title, { category: p.category, language: p.language })}>
                      <Award size={16} /> Audit Certificate
                    </button>
                    <button className="btn secondary" onClick={() => p.openMultiFormat(p.variants[p.selected], p.title)}>
                      <Package size={16} /> Creator Pack (16:9, 9:16, 1:1)
                    </button>
                    <button className="btn secondary" onClick={() => p.openAbBattle(p.variants[p.selected], p.variants[(p.selected + 1) % p.variants.length])}>
                      <Swords size={16} /> A/B Battle
                    </button>
                    <button className="btn primary" onClick={() => p.download(p.variants[p.selected]?.url, p.variants[p.selected]?.label)}>
                      <Download size={16} /> Export PNG
                    </button>
                    <button className="btn secondary" onClick={() => p.openInEditor(p.variants[p.selected]?.url, p.variants[p.selected]?.label)}>
                      <Edit3 size={16} /> Open Editor
                    </button>
                  </div>

                  <div className="seo-pack-panel">
                    <div className="seo-pack-head">
                      <h4><Tag size={15} color="#a78bfa" /> High-CTR YouTube SEO & Tag Pack</h4>
                      <button
                        type="button"
                        className="btn primary sm"
                        onClick={() => {
                          const tags = [p.title, p.category, p.language, 'Viral 2026', 'YouTube Shorts', 'High CTR', 'Trending', 'Must Watch', 'Tips', 'Explained'].join(', ');
                          navigator.clipboard.writeText(`Title: ${p.title}\n\nTags:\n${tags}`);
                          p.setNotice('Copied SEO title & tags to clipboard!');
                        }}
                      >
                        <Copy size={13} /> Copy Metadata Pack
                      </button>
                    </div>
                    <div style={{ display: 'grid', gap: '8px' }}>
                      <div className="seo-title-card">
                        <span className="seo-title-text">⚡ Option 1 (Urgency Hook): {p.language === 'Kannada' ? '🔥 ಶಾಕಿಂಗ್ ಸತ್ಯ! ' + p.title : "🔥 DON'T MISS! " + p.title}</span>
                        <button type="button" className="text-btn sm" onClick={() => { navigator.clipboard.writeText((p.language === 'Kannada' ? '🔥 ಶಾಕಿಂಗ್ ಸತ್ಯ! ' : "🔥 DON'T MISS! ") + p.title); p.setNotice('Copied title!'); }}>Copy</button>
                      </div>
                      <div className="seo-title-card">
                        <span className="seo-title-text">💡 Option 2 (Curiosity Gap): {p.language === 'Kannada' ? 'ಇದು ಹೇಗೆ ಸಾಧ್ಯ? ' + p.title + ' (ಸಂಪೂರ್ಣ ಮಾಹಿತಿ)' : 'HOW IS THIS POSSIBLE? ' + p.title + ' (Full Guide)'}</span>
                        <button type="button" className="text-btn sm" onClick={() => { navigator.clipboard.writeText((p.language === 'Kannada' ? 'ಇದು ಹೇಗೆ ಸಾಧ್ಯ? ' + p.title + ' (ಸಂಪೂರ್ಣ ಮಾಹಿತಿ)' : 'HOW IS THIS POSSIBLE? ' + p.title + ' (Full Guide)')); p.setNotice('Copied title!'); }}>Copy</button>
                      </div>
                    </div>
                    <div>
                      <span style={{ fontSize: '11px', color: '#9d94b4', fontWeight: 700 }}>15 Optimised Search Tags for YouTube Studio:</span>
                      <div className="seo-tags-wrap">
                        {[p.title, p.category, p.language, 'High CTR', 'Viral 2026', 'Trending Topic', 'Best Strategy', 'Explained', 'Tutorial', 'YouTube Growth', 'Secret Hacks', 'Must Watch', 'Reaction', 'Review', 'Creator Tips'].map(tag => (
                          <span key={tag} className="seo-tag-chip">#{tag.replace(/\s+/g, '')}</span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="results-empty">
                <div className="empty-art">
                  <div className="empty-frame"><ImageIcon size={30} /><Sparkles size={17} /></div>
                  <span className="orbit orbit-a" /><span className="orbit orbit-b" />
                </div>
                <h3>Ten candidate compositions. Top five surfaced.</h3>
                <p>Upload at least one person image and specify a title to run the multi-candidate scoring pipeline.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

// -------------------------------------------------------------
// PAGE: Interactive Editor Module
// -------------------------------------------------------------
function Editor({ initialImage, initialTitle, setNotice, setPage, openSimulator, openMultiFormat }) {
  const canvasRef = useRef(null);
  const [showSafeZone, setShowSafeZone] = useState(false);
  const [headline, setHeadline] = useState(initialTitle || 'ನಿಮಗೆ ಗೊತ್ತಾ?');
  const [subtitle, setSubtitle] = useState('AMAZING FACTS');
  const [badgeText, setBadgeText] = useState('🔥 MUST WATCH');
  const [textColor, setTextColor] = useState('#fff500');
  const [strokeColor, setStrokeColor] = useState('#000000');
  const [fontSize, setFontSize] = useState(72);
  const [strokeWidth, setStrokeWidth] = useState(16);
  const [fontFamily, setFontFamily] = useState('Nirmala UI');
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);
  const [bgImg, setBgImg] = useState(null);

  // Viral Stickers & Callouts state
  const [stickerType, setStickerType] = useState('none');
  const [stickerX, setStickerX] = useState(720);
  const [stickerY, setStickerY] = useState(420);
  const [stickerScale, setStickerScale] = useState(1.0);
  const [stickerRotation, setStickerRotation] = useState(0);
  const [stickerColor, setStickerColor] = useState('#ef4444');

  // Rim Light & Glow Halo state
  const [rimLight, setRimLight] = useState(false);
  const [rimLightColor, setRimLightColor] = useState('#ffffff');

  useEffect(() => {
    if (initialImage) {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.src = initialImage;
      img.onload = () => {
        setBgImg(img);
        renderCanvas(img);
      };
    } else {
      renderCanvas(null);
    }
  }, [initialImage]);

  useEffect(() => {
    renderCanvas(bgImg);
  }, [headline, subtitle, badgeText, textColor, strokeColor, fontSize, strokeWidth, fontFamily, brightness, contrast, bgImg, stickerType, stickerX, stickerY, stickerScale, stickerRotation, stickerColor, rimLight, rimLightColor]);

  function renderCanvas(baseImg) {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const W = 1280, H = 720;
    canvas.width = W;
    canvas.height = H;

    ctx.clearRect(0, 0, W, H);

    // Filter
    ctx.filter = `brightness(${brightness}%) contrast(${contrast}%)`;

    if (baseImg) {
      ctx.drawImage(baseImg, 0, 0, W, H);
    } else {
      const grad = ctx.createLinearGradient(0, 0, W, H);
      grad.addColorStop(0, '#1e1b4b');
      grad.addColorStop(0.5, '#0f172a');
      grad.addColorStop(1, '#020617');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, W, H);
    }
    ctx.filter = 'none';

    // Rim Lighting Glow Halo
    if (rimLight) {
      ctx.save();
      ctx.shadowColor = rimLightColor;
      ctx.shadowBlur = 32;
      ctx.strokeStyle = rimLightColor;
      ctx.lineWidth = 10;
      ctx.beginPath();
      ctx.roundRect(14, 14, W - 28, H - 28, 16);
      ctx.stroke();
      ctx.restore();
    }

    // Badge
    if (badgeText.trim()) {
      ctx.save();
      ctx.font = 'bold 18px "Segoe UI Emoji", "Nirmala UI", Arial, sans-serif';
      const bW = ctx.measureText(badgeText).width + 36;
      ctx.fillStyle = 'rgba(234, 179, 8, 0.25)';
      ctx.strokeStyle = '#facc15';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.roundRect(640, 110, bW, 40, 20);
      ctx.fill();
      ctx.stroke();
      ctx.fillStyle = '#fef08a';
      ctx.fillText(badgeText, 658, 136);
      ctx.restore();
    }

    // Headline
    if (headline.trim()) {
      ctx.save();
      ctx.font = `900 ${fontSize}px "${fontFamily}", "Arial Black", Impact, sans-serif`;
      ctx.lineJoin = 'round';

      // 3D Shadow
      ctx.fillStyle = 'rgba(0,0,0,0.95)';
      ctx.fillText(headline, 645, 260);

      // Stroke
      ctx.lineWidth = strokeWidth;
      ctx.strokeStyle = strokeColor;
      ctx.strokeText(headline, 640, 255);

      // Gradient Fill
      const grad = ctx.createLinearGradient(640, 255 - fontSize, 640, 255);
      grad.addColorStop(0, '#ffffff');
      grad.addColorStop(1, textColor);
      ctx.fillStyle = grad;
      ctx.fillText(headline, 640, 255);
      ctx.restore();
    }

    // Subtitle
    if (subtitle.trim()) {
      ctx.save();
      const subFontSize = Math.round(fontSize * 0.75);
      ctx.font = `900 ${subFontSize}px "${fontFamily}", "Arial Black", Impact, sans-serif`;
      ctx.lineJoin = 'round';

      ctx.fillStyle = 'rgba(0,0,0,0.95)';
      ctx.fillText(subtitle, 645, 260 + fontSize + 20);

      ctx.lineWidth = strokeWidth;
      ctx.strokeStyle = strokeColor;
      ctx.strokeText(subtitle, 640, 255 + fontSize + 20);

      ctx.fillStyle = '#ffffff';
      ctx.fillText(subtitle, 640, 255 + fontSize + 20);
      ctx.restore();
    }

    // Viral Stickers & Callouts
    if (stickerType !== 'none') {
      ctx.save();
      ctx.translate(stickerX, stickerY);
      ctx.rotate((stickerRotation * Math.PI) / 180);
      ctx.scale(stickerScale, stickerScale);

      if (stickerType === 'arrow') {
        ctx.strokeStyle = stickerColor;
        ctx.fillStyle = stickerColor;
        ctx.lineWidth = 14;
        ctx.lineCap = 'round';
        ctx.shadowColor = stickerColor;
        ctx.shadowBlur = 18;

        ctx.beginPath();
        ctx.moveTo(-60, 40);
        ctx.quadraticCurveTo(0, -30, 70, 0);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(70, 0);
        ctx.lineTo(40, -25);
        ctx.lineTo(45, 10);
        ctx.closePath();
        ctx.fill();
      } else if (stickerType === 'circle') {
        ctx.strokeStyle = stickerColor;
        ctx.lineWidth = 10;
        ctx.shadowColor = stickerColor;
        ctx.shadowBlur = 20;

        ctx.beginPath();
        ctx.ellipse(0, 0, 75, 75, 0, 0, 2 * Math.PI);
        ctx.stroke();

        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.ellipse(0, 0, 88, 88, 0, 0, 2 * Math.PI);
        ctx.stroke();
      } else if (stickerType === 'vs') {
        ctx.shadowColor = stickerColor;
        ctx.shadowBlur = 25;

        ctx.fillStyle = '#0f0c19';
        ctx.strokeStyle = stickerColor;
        ctx.lineWidth = 6;
        ctx.beginPath();
        ctx.moveTo(0, -55);
        ctx.lineTo(55, 0);
        ctx.lineTo(0, 55);
        ctx.lineTo(-55, 0);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        ctx.font = '900 48px "Arial Black", Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#ffffff';
        ctx.lineWidth = 8;
        ctx.strokeStyle = '#000000';
        ctx.strokeText('VS', 0, 2);
        ctx.fillText('VS', 0, 2);
      } else if (stickerType === '4k') {
        ctx.shadowColor = stickerColor;
        ctx.shadowBlur = 15;
        ctx.fillStyle = stickerColor;
        ctx.beginPath();
        ctx.roundRect(-70, -28, 140, 56, 12);
        ctx.fill();

        ctx.font = '900 28px "Arial Black", Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#000000';
        ctx.fillText('4K ULTRA', 0, 0);
      } else if (stickerType === 'alert') {
        ctx.shadowColor = stickerColor;
        ctx.shadowBlur = 20;
        ctx.fillStyle = '#111827';
        ctx.strokeStyle = stickerColor;
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.roundRect(-85, -28, 170, 56, 10);
        ctx.fill();
        ctx.stroke();

        ctx.font = '900 24px "Arial Black", Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = stickerColor;
        ctx.fillText('⚠️ ALERT', 0, 0);
      } else if (stickerType === 'starburst') {
        ctx.fillStyle = stickerColor;
        ctx.shadowColor = stickerColor;
        ctx.shadowBlur = 22;
        ctx.beginPath();
        const spikes = 12;
        const outerR = 65, innerR = 40;
        for (let i = 0; i < spikes * 2; i++) {
          const r = i % 2 === 0 ? outerR : innerR;
          const a = (i * Math.PI) / spikes;
          const x = Math.cos(a) * r;
          const y = Math.sin(a) * r;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();

        ctx.font = '900 22px "Arial Black", Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#000000';
        ctx.fillText('NEW!', 0, 0);
      }

      ctx.restore();
    }
  }

  function downloadEdited() {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = 'thumblify-edited-1280x720.png';
    link.href = canvas.toDataURL('image/png');
    link.click();
    setNotice('Exported edited 1280×720 thumbnail!');
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">POST-GENERATION CANVAS EDITOR</div>
          <h1>Thumbnail Editor</h1>
          <p>Interactive canvas adjustments: fine-tune typography, stroke weights, badges, and real-time color filters.</p>
        </div>
        <button className="btn primary" onClick={downloadEdited}><Download size={16} /> Export 1280×720 PNG</button>
      </div>

      <div className="editor-layout">
        <div className="editor-canvas-card">
          <div className="canvas-holder preview-thumb-container">
            <canvas ref={canvasRef} />
            {showSafeZone && (
              <div className="preview-safe-overlay">
                <div className="preview-safe-margins" />
                <div className="preview-safe-deadzone">
                  YT DEAD ZONE
                </div>
                <span className="preview-safe-timestamp">14:28</span>
              </div>
            )}
          </div>
          <div className="editor-toolbar">
            <label className="sim-toggle">
              <input
                type="checkbox"
                checked={showSafeZone}
                onChange={e => setShowSafeZone(e.target.checked)}
              />
              <span>🛡️ Safe Area Guides</span>
            </label>
            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                className="btn accent sm"
                onClick={() => {
                  const canvas = canvasRef.current;
                  if (canvas) openSimulator({ url: canvas.toDataURL('image/png') }, headline);
                }}
              >
                <MonitorPlay size={14} /> Preview in YouTube
              </button>
              <button
                className="btn secondary sm"
                onClick={() => {
                  const canvas = canvasRef.current;
                  if (canvas) openMultiFormat({ url: canvas.toDataURL('image/png') }, headline);
                }}
              >
                <Package size={14} /> Creator Pack
              </button>
              <button className="btn secondary sm" onClick={() => setPage('Generate Thumbnail')}>Back to Generator</button>
              <button className="btn primary sm" onClick={downloadEdited}><Download size={14} /> Download</button>
            </div>
          </div>
        </div>

        <div className="editor-tools-panel">
          <div className="editor-section">
            <h4><Edit3 size={14} /> Text Layers</h4>
            <label>Headline (Kannada / English)
              <input value={headline} onChange={e => setHeadline(e.target.value)} />
            </label>
            <label style={{ marginTop: '10px' }}>Subtitle
              <input value={subtitle} onChange={e => setSubtitle(e.target.value)} />
            </label>
            <label style={{ marginTop: '10px' }}>Badge Pill
              <input value={badgeText} onChange={e => setBadgeText(e.target.value)} />
            </label>
          </div>

          <div className="editor-section">
            <h4><Palette size={14} /> Typography & Colors</h4>
            <div className="two-col">
              <label>Font Family
                <select value={fontFamily} onChange={e => setFontFamily(e.target.value)}>
                  <option>Nirmala UI</option>
                  <option>Impact</option>
                  <option>Arial Black</option>
                  <option>Segoe UI</option>
                </select>
              </label>
              <div className="color-picker-row" style={{ marginTop: '22px' }}>
                <input type="color" value={textColor} onChange={e => setTextColor(e.target.value)} title="Text Fill" />
                <span style={{ fontSize: '10px' }}>Text Fill</span>
                <input type="color" value={strokeColor} onChange={e => setStrokeColor(e.target.value)} title="Outline" />
                <span style={{ fontSize: '10px' }}>Outline</span>
              </div>
            </div>

            <div className="slider-group" style={{ marginTop: '12px' }}>
              <label><span>Font Size</span><span>{fontSize}px</span></label>
              <input type="range" min="40" max="110" value={fontSize} onChange={e => setFontSize(Number(e.target.value))} />
            </div>

            <div className="slider-group">
              <label><span>Outline Width</span><span>{strokeWidth}px</span></label>
              <input type="range" min="0" max="28" value={strokeWidth} onChange={e => setStrokeWidth(Number(e.target.value))} />
            </div>

            <div style={{ marginTop: '14px' }}>
              <label style={{ fontSize: '11px', color: '#a78bfa', fontWeight: 700 }}>🎨 Smart Viral Color Harmonies</label>
              <div className="harmony-presets-grid">
                {[
                  { name: '⚡ Cyber Viral', text: '#facc15', stroke: '#000000', badge: '🔥 VIRAL' },
                  { name: '🚨 Breaking Danger', text: '#ffffff', stroke: '#000000', badge: '⚠️ BREAKING' },
                  { name: '💎 Tech Clean', text: '#38bdf8', stroke: '#0f172a', badge: '⚡ 4K ULTRA' },
                  { name: '👑 Kannada Gold', text: '#f59e0b', stroke: '#3b0764', badge: '🏆 EXCLUSIVE' },
                ].map(h => (
                  <div
                    key={h.name}
                    className="harmony-card"
                    onClick={() => {
                      setTextColor(h.text);
                      setStrokeColor(h.stroke);
                      setBadgeText(h.badge);
                    }}
                  >
                    <span style={{ fontSize: '11px', fontWeight: 700, color: '#f1edff' }}>{h.name}</span>
                    <div className="harmony-colors">
                      <div style={{ flex: 1, background: h.text }} />
                      <div style={{ flex: 1, background: h.stroke }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="editor-section">
            <h4><Sliders size={14} /> Color Grading</h4>
            <div className="slider-group">
              <label><span>Brightness</span><span>{brightness}%</span></label>
              <input type="range" min="60" max="150" value={brightness} onChange={e => setBrightness(Number(e.target.value))} />
            </div>
            <div className="slider-group">
              <label><span>Contrast</span><span>{contrast}%</span></label>
              <input type="range" min="70" max="160" value={contrast} onChange={e => setContrast(Number(e.target.value))} />
            </div>

            <div style={{ marginTop: '14px', paddingTop: '10px', borderTop: '1px solid #281c3c' }}>
              <label className="sim-toggle" style={{ margin: 0 }}>
                <input
                  type="checkbox"
                  checked={rimLight}
                  onChange={e => setRimLight(e.target.checked)}
                />
                <span>✨ Neon Subject Rim Light & Glow Halo</span>
              </label>
              {rimLight && (
                <div style={{ marginTop: '8px', display: 'flex', gap: '6px', alignItems: 'center' }}>
                  <span style={{ fontSize: '10.5px', color: '#9d94b4' }}>Halo Glow:</span>
                  {['#ffffff', '#facc15', '#06b6d4', '#ec4899', '#10b981'].map(c => (
                    <button
                      key={c}
                      type="button"
                      className={`color-swatch-btn ${rimLightColor === c ? 'active' : ''}`}
                      style={{ background: c, width: '18px', height: '18px' }}
                      onClick={() => setRimLightColor(c)}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="editor-section">
            <h4>Quick Emojis</h4>
            <div className="sticker-chips">
              {['🔥', '😱', '🚨', '👑', '💥', '✨', '⚡', '❤️'].map(emo => (
                <button key={emo} type="button" className="sticker-chip" onClick={() => setBadgeText(prev => `${emo} ${prev.replace(/^[^\w\s]+\s*/, '')}`)}>
                  {emo}
                </button>
              ))}
            </div>
          </div>

          <div className="editor-section">
            <h4><Sticker size={14} /> Viral Stickers & Callouts</h4>
            <div className="sticker-picker-grid">
              {[
                { id: 'none', label: '🚫 None' },
                { id: 'arrow', label: '🏹 Curved Arrow' },
                { id: 'circle', label: '🎯 Focus Circle' },
                { id: 'vs', label: '⚔️ VS Badge' },
                { id: '4k', label: '💎 4K Ultra HD' },
                { id: 'alert', label: '⚠️ Warning Alert' },
                { id: 'starburst', label: '💥 Action Star' },
              ].map(st => (
                <button
                  key={st.id}
                  type="button"
                  className={`sticker-pick-btn ${stickerType === st.id ? 'active' : ''}`}
                  onClick={() => setStickerType(st.id)}
                >
                  {st.label}
                </button>
              ))}
            </div>

            {stickerType !== 'none' && (
              <>
                <div className="slider-group">
                  <div className="slider-label"><span>Position X</span><span>{stickerX}px</span></div>
                  <input type="range" min="100" max="1180" value={stickerX} onChange={e => setStickerX(Number(e.target.value))} />
                </div>
                <div className="slider-group">
                  <div className="slider-label"><span>Position Y</span><span>{stickerY}px</span></div>
                  <input type="range" min="80" max="640" value={stickerY} onChange={e => setStickerY(Number(e.target.value))} />
                </div>
                <div className="slider-group">
                  <div className="slider-label"><span>Scale</span><span>{stickerScale.toFixed(1)}x</span></div>
                  <input type="range" min="0.5" max="2.0" step="0.1" value={stickerScale} onChange={e => setStickerScale(Number(e.target.value))} />
                </div>
                <div className="slider-group">
                  <div className="slider-label"><span>Rotation</span><span>{stickerRotation}°</span></div>
                  <input type="range" min="-180" max="180" step="5" value={stickerRotation} onChange={e => setStickerRotation(Number(e.target.value))} />
                </div>
                <div style={{ marginTop: '10px' }}>
                  <div className="slider-label"><span>Glow & Accent Color</span></div>
                  <div className="color-swatches">
                    {['#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#ffffff'].map(c => (
                      <button
                        key={c}
                        type="button"
                        className={`color-swatch-btn ${stickerColor === c ? 'active' : ''}`}
                        style={{ background: c }}
                        onClick={() => setStickerColor(c)}
                        title={c}
                      />
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </>
  );
}

// -------------------------------------------------------------
// PAGE: Templates (Table III in Paper)
// -------------------------------------------------------------
function Templates({ templates, applyTemplate }) {
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">PRESET FORMATS</div>
          <h1>Thumbnail Templates</h1>
          <p>Reusable compositional recipes tailored to Kannada serials, tech reviews, travel vlogs, and breaking news.</p>
        </div>
      </div>

      <div className="templates-grid">
        {templates.map(tmpl => (
          <div key={tmpl.id} className="template-card">
            <div className="template-banner" style={{ background: tmpl.gradient }}>
              <span className="template-tag">{tmpl.category.toUpperCase()}</span>
              <span className="template-emoji">{tmpl.emoji}</span>
              <h3>{tmpl.title}</h3>
            </div>
            <div className="template-body">
              <p>{tmpl.description}</p>
              <div className="template-foot">
                <span className="template-meta">{tmpl.language} • {tmpl.style}</span>
                <button className="btn primary sm" onClick={() => applyTemplate(tmpl)}>
                  Use Template <ArrowUpRight size={13} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

// -------------------------------------------------------------
// PAGE: Settings & Brand Kit
// -------------------------------------------------------------
function SettingsPage({ user, setUser, setNotice, setError }) {
  const [channelName, setChannelName] = useState(user.brandKit?.channelName || '');
  const [defaultScript, setDefaultScript] = useState(user.brandKit?.defaultScript || 'Kannada');
  const [primaryColor, setPrimaryColor] = useState(user.brandKit?.primaryColor || '#f59e0b');
  const [secondaryColor, setSecondaryColor] = useState(user.brandKit?.secondaryColor || '#ef4444');
  const [defaultFont, setDefaultFont] = useState(user.brandKit?.defaultFont || 'Nirmala UI');
  const [category, setCategory] = useState(user.brandKit?.category || 'Vlog');
  const [saving, setSaving] = useState(false);

  async function saveBrandKit(e) {
    e.preventDefault(); setSaving(true);
    try {
      const res = await api('/auth/brand-kit', {
        method: 'PUT',
        body: JSON.stringify({ channelName, defaultScript, primaryColor, secondaryColor, defaultFont, category })
      });
      setUser(current => current ? ({ ...current, brandKit: res.brandKit }) : current);
      setNotice('Brand Kit settings saved successfully.');
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">ACCOUNT & BRAND CONFIGURATION</div>
          <h1>Settings & Brand Kit</h1>
          <p>Configure your YouTube channel identity, default script, and custom brand color palette.</p>
        </div>
      </div>

      <div className="settings-layout">
        <div className="panel">
          <div className="panel-title">
            <div className="step-num"><Palette size={14} /></div>
            <div>
              <h3>Brand Kit Configuration</h3>
              <p>Applied automatically across your new generation briefs.</p>
            </div>
          </div>

          <form className="settings-form" onSubmit={saveBrandKit}>
            <label>YouTube Channel Name
              <input value={channelName} onChange={e => setChannelName(e.target.value)} placeholder="e.g. Karnataka Explorer" />
            </label>

            <div className="two-col">
              <label>Default Script
                <select value={defaultScript} onChange={e => setDefaultScript(e.target.value)}>
                  <option>Kannada</option>
                  <option>English</option>
                </select>
              </label>
              <label>Default Category
                <select value={category} onChange={e => setCategory(e.target.value)}>
                  {categories.map(c => <option key={c}>{c}</option>)}
                </select>
              </label>
            </div>

            <div className="two-col">
              <label>Preferred Font
                <select value={defaultFont} onChange={e => setDefaultFont(e.target.value)}>
                  <option>Nirmala UI</option>
                  <option>Impact</option>
                  <option>Arial Black</option>
                  <option>Segoe UI</option>
                </select>
              </label>
              <div style={{ display: 'flex', gap: '15px', alignItems: 'center', marginTop: '18px' }}>
                <div>
                  <small style={{ display: 'block', fontSize: '10px', color: '#9d94b4' }}>Primary</small>
                  <input type="color" value={primaryColor} onChange={e => setPrimaryColor(e.target.value)} style={{ width: 36, height: 36, border: 0, background: 'transparent' }} />
                </div>
                <div>
                  <small style={{ display: 'block', fontSize: '10px', color: '#9d94b4' }}>Accent</small>
                  <input type="color" value={secondaryColor} onChange={e => setSecondaryColor(e.target.value)} style={{ width: 36, height: 36, border: 0, background: 'transparent' }} />
                </div>
              </div>
            </div>

            <button className="btn primary" disabled={saving}>
              {saving ? <LoaderCircle className="spin" size={15} /> : <CheckCircle2 size={15} />} Save Brand Kit
            </button>
          </form>
        </div>

        <div className="panel">
          <div className="panel-title">
            <div className="step-num"><SettingsIcon size={14} /></div>
            <div>
              <h3>Account Profile</h3>
              <p>Authentication metadata and generation credit quota.</p>
            </div>
          </div>

          <div className="brand-kit-card">
            <div><small style={{ color: '#8d82a4' }}>Creator Name</small><b>{user.name}</b></div>
            <div><small style={{ color: '#8d82a4' }}>Email Address</small><b>{user.email}</b></div>
            <div><small style={{ color: '#8d82a4' }}>Available Generation Credits</small><b>{user.credits ?? 20} credits</b></div>
            <div><small style={{ color: '#8d82a4' }}>Platform Version</small><b>Thumblify 1.0 (Implementation-Grounded)</b></div>
          </div>
        </div>
      </div>
    </>
  );
}

// -------------------------------------------------------------
// Helper Components (AuthScreen, Analyzer, PromptStudio, etc.)
// -------------------------------------------------------------
function AuthScreen({ mode, setMode, form, setForm, submit, loading, error }) {
  return (
    <div className="auth-page">
      <div className="auth-art">
        <div className="auth-orb orb-one" /><div className="auth-orb orb-two" />
        <div className="auth-brand"><div className="brand-mark"><Sparkles size={22} /></div><b>thumblify<span>.ai</span></b></div>
        <div className="auth-copy">
          <div className="eyebrow"><Sparkles size={14} /> NEXT-GEN CREATOR PLATFORM</div>
          <h1>Make every<br /><span>click-worthy</span><br />moment.</h1>
          <p>Production-grade platform for automated YouTube thumbnail composition, layout ranking, and visual quality auditing.</p>
        </div>
        <div className="auth-art-foot">HIGH-CTR THUMBNAIL STUDIO • 1280×720 HD</div>
      </div>
      <div className="auth-form-wrap">
        <form className="auth-form" onSubmit={submit}>
          <div className="auth-mobile-logo"><div className="brand-mark"><Sparkles size={20} /></div><b>thumblify<span>.ai</span></b></div>
          <div className="eyebrow">WELCOME {mode === 'login' ? 'BACK' : 'ABOARD'}</div>
          <h2>{mode === 'login' ? 'Sign in to workspace' : 'Create creator account'}</h2>
          {error && <div className="alert error"><AlertCircle size={16} />{error}</div>}
          {mode === 'register' && (
            <label>Full Name
              <input required minLength="2" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your name" />
            </label>
          )}
          <label>Email Address
            <input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" />
          </label>
          <label>Password
            <input required minLength="10" type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="At least 10 characters" />
            <small>At least 10 characters.</small>
          </label>
          <button className="btn primary wide" disabled={loading}>
            {loading ? <LoaderCircle className="spin" size={17} /> : null}
            {mode === 'login' ? 'Sign in to studio' : 'Create account'} <ArrowUpRight size={16} />
          </button>
          <div className="auth-switch">
            {mode === 'login' ? "Don't have an account?" : "Already have an account?"}{' '}
            <button type="button" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
              {mode === 'login' ? 'Create account' : 'Sign in'}
            </button>
          </div>
          <div className="secure-note"><ShieldCheck size={15} /> Your account and projects stay protected.</div>
        </form>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, hint }) {
  return (
    <div className="stat-card">
      <div className="stat-top"><span>{label}</span><div className="stat-icon"><Icon size={17} /></div></div>
      <strong>{value}</strong><small>{hint}</small>
    </div>
  );
}

function ToolCard({ icon: Icon, color, title, desc, action, onClick }) {
  return (
    <div className="tool-card">
      <div className={`tool-icon ${color}`}><Icon size={19} /></div>
      <h3>{title}</h3>
      <p>{desc}</p>
      <button className="text-btn" onClick={onClick}>{action} <ArrowUpRight size={14} /></button>
    </div>
  );
}

function Analyzer(p) {
  const [showHeatmap, setShowHeatmap] = useState(false);
  const [showSafeZone, setShowSafeZone] = useState(false);
  const canvasRef = useRef(null);

  useEffect(() => {
    if (!showHeatmap || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const W = 1280, H = 720;
    canvas.width = W;
    canvas.height = H;
    ctx.clearRect(0, 0, W, H);

    // Simulated Eye-Tracking Attention Density (Fixation Map)
    // Primary Fixation: Left-Center Title Area
    const g1 = ctx.createRadialGradient(W * 0.36, H * 0.44, 20, W * 0.36, H * 0.44, 380);
    g1.addColorStop(0, 'rgba(239, 68, 68, 0.85)');
    g1.addColorStop(0.25, 'rgba(245, 158, 11, 0.7)');
    g1.addColorStop(0.55, 'rgba(16, 185, 129, 0.45)');
    g1.addColorStop(0.8, 'rgba(59, 130, 246, 0.25)');
    g1.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = g1;
    ctx.fillRect(0, 0, W, H);

    // Secondary Fixation: Subject Face Area (Right or Center)
    const g2 = ctx.createRadialGradient(W * 0.74, H * 0.4, 25, W * 0.74, H * 0.4, 340);
    g2.addColorStop(0, 'rgba(239, 68, 68, 0.9)');
    g2.addColorStop(0.28, 'rgba(245, 158, 11, 0.75)');
    g2.addColorStop(0.6, 'rgba(16, 185, 129, 0.4)');
    g2.addColorStop(0.85, 'rgba(59, 130, 246, 0.2)');
    g2.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = g2;
    ctx.fillRect(0, 0, W, H);

    // Tertiary subtle gaze fixation
    const g3 = ctx.createRadialGradient(W * 0.5, H * 0.55, 15, W * 0.5, H * 0.55, 260);
    g3.addColorStop(0, 'rgba(245, 158, 11, 0.5)');
    g3.addColorStop(0.5, 'rgba(16, 185, 129, 0.25)');
    g3.addColorStop(1, 'rgba(0, 0, 0, 0)');
    ctx.fillStyle = g3;
    ctx.fillRect(0, 0, W, H);
  }, [showHeatmap, p.analysis]);

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">NO-REFERENCE IMAGE QUALITY ASSESSMENT</div>
          <h1>Thumbnail Analyzer</h1>
          <p>Audits a published thumbnail out of 100 across 6 pixel-level quality dimensions with eye-tracking simulation.</p>
        </div>
      </div>
      <div className="analyzer-layout">
        <form className="panel analyzer-upload" onSubmit={p.runAnalysis}>
          <div className="panel-title">
            <div className="step-num">01</div>
            <div><h3>Upload thumbnail</h3><p>Evaluates brightness, contrast, and 16:9 compliance.</p></div>
          </div>
          <label className="upload-zone analyzer-zone">
            <input type="file" accept="image/png,image/jpeg,image/webp" onChange={e => p.setAnalyzeFile(e.target.files?.[0] || null)} />
            <div className="upload-icon"><ScanSearch size={24} /></div>
            <b>{p.analyzeFile?.name || 'Choose a thumbnail to audit'}</b>
            <span>PNG, JPG or WebP</span>
          </label>
          <button className="btn primary wide" disabled={p.loading || !p.analyzeFile}>
            {p.loading ? <LoaderCircle className="spin" size={17} /> : <ScanSearch size={17} />} Run Quality Analysis
          </button>
        </form>
        <div className="panel analysis-results">
          {p.analysis ? (
            <>
              <div className="preview-toolbar">
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
                  <label className="sim-toggle">
                    <input
                      type="checkbox"
                      checked={showHeatmap}
                      onChange={e => setShowHeatmap(e.target.checked)}
                    />
                    <span>🔥 Attention Heatmap</span>
                  </label>
                  <label className="sim-toggle">
                    <input
                      type="checkbox"
                      checked={showSafeZone}
                      onChange={e => setShowSafeZone(e.target.checked)}
                    />
                    <span>🛡️ Safe Area (14:28)</span>
                  </label>
                </div>
                {p.analysis.imageUrl && (
                  <button
                    type="button"
                    className="btn accent sm"
                    onClick={() => p.openSimulator({ url: p.analysis.imageUrl }, p.analyzeFile?.name || 'Audited Thumbnail')}
                  >
                    <MonitorPlay size={14} /> Preview in YouTube Feed
                  </button>
                )}
              </div>

              {p.analysis.imageUrl && (
                <div className="heatmap-container">
                  <img src={assetUrl(p.analysis.imageUrl)} alt="Audited thumbnail" />
                  {showHeatmap && <canvas ref={canvasRef} className="heatmap-canvas" />}
                  {showSafeZone && (
                    <div className="preview-safe-overlay">
                      <div className="preview-safe-margins" />
                      <div className="preview-safe-deadzone">
                        YT DEAD ZONE
                      </div>
                      <span className="preview-safe-timestamp">14:28</span>
                    </div>
                  )}
                </div>
              )}

              {showHeatmap && (
                <div className="heatmap-legend">
                  <span>Simulated Eye-Tracking Attention: 500ms Gaze Density</span>
                  <div className="heatmap-bar-wrap">
                    <span>Low</span>
                    <div className="heatmap-bar" />
                    <span>High Hotspot</span>
                  </div>
                </div>
              )}

              <div className="eyebrow" style={{ marginTop: '16px' }}>ANALYSIS AUDIT REPORT</div>
              <h2>Visual Quality Score</h2>
              <div className="analysis-score">
                <div className="score-ring" style={{ '--score': `${p.analysis.score}%` }}>
                  <div><b>{p.analysis.score}</b><small>/100</small></div>
                </div>
                <div>
                  <b>{p.analysis.score >= 80 ? 'Strong Visual Quality' : 'Improvements Recommended'}</b>
                  <p>Derived from pixel-level statistical regularities across natural image dimensions.</p>
                </div>
              </div>
              <div className="metric-grid">
                {Object.entries(p.analysis.metrics || {}).filter(([k]) => ['width', 'height', 'brightness', 'contrast', 'saturation', 'exposure', 'colorBalance', 'aspectRatioCompliance'].includes(k)).map(([k, v]) => (
                  <div key={k}><small>{k}</small><b>{v ?? '—'}</b></div>
                ))}
              </div>
              <h3>Recommendations</h3>
              <ul className="recommendations">{p.analysis.recommendations.map((r, i) => <li key={i}><CheckCircle2 size={16} />{r}</li>)}</ul>
            </>
          ) : (
            <div className="analysis-placeholder">
              <div className="analysis-orb"><ScanSearch size={29} /></div>
              <h3>Diagnostics for underperforming thumbnails.</h3>
              <p>Upload any existing thumbnail to inspect its score across all 6 research dimensions and test attention heatmaps.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function PromptStudio(p) {
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">CREATIVE BRIEF REFINEMENT</div>
          <h1>Prompt Studio</h1>
          <p>Structure production-ready thumbnail briefs with mobile-first readability guidance.</p>
        </div>
      </div>
      <div className="prompt-layout">
        <form className="panel prompt-form" onSubmit={p.runPrompt}>
          <label>Prompt Idea
            <textarea rows="7" value={p.prompt} onChange={e => p.setPrompt(e.target.value)} maxLength="2000" required placeholder="Describe your thumbnail concept..." />
          </label>
          <button className="btn primary wide" disabled={p.loading}>
            {p.loading ? <LoaderCircle size={17} className="spin" /> : <WandSparkles size={17} />} Refine Creative Prompt
          </button>
        </form>
        <div className="panel refined-panel">
          <div className="eyebrow">REFINED ART DIRECTION</div>
          {p.refined ? (
            <>
              <div className="refined-output">{p.refined}</div>
              <button className="btn primary wide" onClick={() => { p.setTitle(p.refined.slice(0, 140)); p.setPage('Generate Thumbnail'); }}>
                <WandSparkles size={16} /> Use as Generator Title
              </button>
            </>
          ) : (
            <div className="prompt-empty">
              <div className="prompt-spark"><Sparkles size={26} /></div>
              <h3>AI-Assisted Thumbnail Direction</h3>
              <p>Refines composition, focal subjects, lighting, and negative space for clean Kannada/English typography.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function Generations({ generations, download, openInEditor, setPage, openSimulator, openMultiFormat, openAbBattle, openAuditCert }) {
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">GENERATION HISTORY</div>
          <h1>My Generations</h1>
          <p>Review past thumbnail generation runs, layout scores, and export or edit any candidate.</p>
        </div>
        <button className="btn primary" onClick={() => setPage('Generate Thumbnail')}><Plus size={16} /> New Generation</button>
      </div>
      {generations.length ? (
        <div className="project-grid">
          {generations.map(g => (
            <div className="project-card" key={g._id}>
              <div className="project-image" onClick={() => g.variants?.[0] && download(g.variants[0].url, g.title)}>
                {g.variants?.[0] ? <img src={assetUrl(g.variants[0].url)} alt={g.title} /> : <div className="project-placeholder"><ImageIcon size={25} /></div>}
                <span>Score: {g.bestScore ?? g.variants?.[0]?.score ?? 0}/100</span>
              </div>
              <div className="project-card-info">
                <div>
                  <h3>{g.title}</h3>
                  <p>{g.category} • {g.language}</p>
                </div>
              </div>
              <div className="project-card-foot">
                <span>{new Date(g.createdAt).toLocaleDateString()}</span>
                <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                  {g.variants?.[0] && (
                    <button className="text-btn" onClick={() => openSimulator(g.variants[0], g.title)}>Feed <MonitorPlay size={13} /></button>
                  )}
                  {g.variants?.[0] && (
                    <button className="text-btn" onClick={() => openAuditCert(g.variants[0], g.title, { category: g.category, language: g.language })}>Audit <Award size={13} /></button>
                  )}
                  {g.variants?.[0] && (
                    <button className="text-btn" onClick={() => openMultiFormat(g.variants[0], g.title)}>Pack <Package size={13} /></button>
                  )}
                  {g.variants?.length >= 2 && (
                    <button className="text-btn" onClick={() => openAbBattle(g.variants[0], g.variants[1])}>A/B <Swords size={13} /></button>
                  )}
                  {g.variants?.[0] && (
                    <button className="text-btn" onClick={() => openInEditor(g.variants[0].url, g.title)}>Edit <Edit3 size={13} /></button>
                  )}
                  <button className="text-btn" onClick={() => g.variants?.[0] && download(g.variants[0].url, g.title)}>Export <Download size={13} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="empty-icon"><History size={24} /></div>
          <h3>No past generations found</h3>
          <p>Your generation runs and ranked alternatives will appear here.</p>
          <button className="btn primary" onClick={() => setPage('Generate Thumbnail')}>Start First Generation</button>
        </div>
      )}
    </>
  );
}

function Analytics({ analytics }) {
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">PLATFORM TELEMETRY</div>
          <h1>Generation Analytics</h1>
          <p>Tracking generation volume, category distributions, and composite quality scores.</p>
        </div>
      </div>
      {analytics ? (
        <>
          <div className="stats-grid">
            <Stat icon={WandSparkles} label="Total generations" value={analytics.totalGenerations} hint="Total completed runs" />
            <Stat icon={BarChart3} label="Average score" value={`${analytics.averageScore}/100`} hint="7-factor mean score" />
            <Stat icon={Sparkles} label="Best score" value={`${analytics.bestScore}/100`} hint="Highest quality candidate" />
            <Stat icon={Layers} label="Evaluated layouts" value={analytics.totalGenerations * 10} hint="Candidate compositions" />
          </div>
          <div className="panel" style={{ marginTop: '20px' }}>
            <h3>Category Breakdown</h3>
            <p style={{ fontSize: '11px', color: '#9a8fb2', marginBottom: '14px' }}>Generations per content category</p>
            {Object.entries(analytics.byCategory || {}).map(([name, count]) => (
              <div key={name} style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '10px' }}>
                <span style={{ width: '130px', fontSize: '11px' }}>{name}</span>
                <div style={{ flex: 1, height: '7px', background: '#231b34', borderRadius: '4px', overflow: 'hidden' }}>
                  <div style={{ width: `${Math.max(6, (count / Math.max(1, analytics.totalGenerations)) * 100)}%`, height: '100%', background: 'linear-gradient(90deg, #a78bfa, #7c3aed)' }} />
                </div>
                <b style={{ fontSize: '11px', minWidth: '24px' }}>{count}</b>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="panel analysis-placeholder"><LoaderCircle className="spin" size={22} /><p>Loading telemetry…</p></div>
      )}
    </>
  );
}

function Projects({ projects, deleteProject, setPage, download, openSimulator }) {
  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">WORKSPACE REPOSITORY</div>
          <h1>Projects</h1>
          <p>Organize your thumbnail concepts, brand references, and production exports.</p>
        </div>
        <button className="btn primary" onClick={() => setPage('Generate Thumbnail')}><Plus size={16} /> New Project</button>
      </div>
      {projects.length ? (
        <div className="project-grid">
          {projects.map(p => (
            <div className="project-card" key={p._id}>
              <div className="project-image" onClick={() => p.thumbnails?.[0] && download(p.thumbnails[0].url, p.title)}>
                {p.thumbnails?.[0] ? <img src={assetUrl(p.thumbnails[0].url)} alt={p.title} /> : <div className="project-placeholder"><ImageIcon size={25} /></div>}
                <span>{p.thumbnails?.length || 0} renders</span>
              </div>
              <div className="project-card-info">
                <div>
                  <h3>{p.title}</h3>
                  <p>{p.category} • {p.language}</p>
                </div>
                <div style={{ display: 'flex', gap: '6px' }}>
                  {p.thumbnails?.[0] && (
                    <button className="icon-btn" title="Preview in YouTube Feed" onClick={() => openSimulator(p.thumbnails[0], p.title)}><MonitorPlay size={15} /></button>
                  )}
                  <button className="icon-btn" title="Delete" onClick={() => deleteProject(p._id)}><Trash2 size={15} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="empty-state">
          <div className="empty-icon"><FolderOpen size={24} /></div>
          <h3>No projects saved yet</h3>
          <p>Saved projects and generation runs will be stored here.</p>
        </div>
      )}
    </>
  );
}

// -------------------------------------------------------------
// MODAL: YouTube Feed Simulator
// -------------------------------------------------------------
function YouTubeSimulator({ data, onClose }) {
  const [viewMode, setViewMode] = useState('desktop'); // 'desktop' | 'mobile' | 'sidebar'
  const [theme, setTheme] = useState('dark'); // 'dark' | 'light'
  const [activeVariant, setActiveVariant] = useState(0);
  const [timestamp, setTimestamp] = useState('14:28');
  const [viewsStats, setViewsStats] = useState('184K views • 2 hours ago');
  const [showProgress, setShowProgress] = useState(false);
  const [showDeadZone, setShowDeadZone] = useState(false);
  const [channelName] = useState(data.channelName || 'Kannada Tech Studio');

  const variants = data.variants?.length ? data.variants : [{ url: data.imageUrl, label: 'Candidate #1', score: 92 }];
  const currentImg = variants[activeVariant]?.url || data.imageUrl;
  const currentTitle = data.title || 'YouTube Thumbnail Preview';

  // Keyboard escape shortcut
  useEffect(() => {
    function onKeyDown(e) {
      if (e.key === 'Escape') onClose();
    }
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onClose]);

  const competitors = [
    {
      id: 'c1',
      title: 'ಹೊಸ ಸ್ಮಾರ್ಟ್‌ಫೋನ್ ಕೊಳ್ಳುವ ಮುನ್ನ ಇದನ್ನು ನೋಡಿ! Detailed Review',
      channel: 'Tech Sandalwood',
      views: '412K views • 1 day ago',
      time: '18:12',
      bgGrad: 'linear-gradient(135deg, #091e3a, #2f80ed)',
      badge: 'TECH REVIEW'
    },
    {
      id: 'c2',
      title: 'Top 10 Hidden Places in Karnataka You Must Visit in 2026',
      channel: 'Explorer Kannada',
      views: '95K views • 4 hours ago',
      time: '24:40',
      bgGrad: 'linear-gradient(135deg, #134e5e, #71b280)',
      badge: 'TRAVEL VLOG'
    },
    {
      id: 'c3',
      title: 'Shocking Truth Behind This Viral Story! Full Breakdown',
      channel: 'Cinema Insights',
      views: '620K views • 3 days ago',
      time: '09:15',
      bgGrad: 'linear-gradient(135deg, #4b1248, #f0c27b)',
      badge: 'BREAKING VIRAL'
    }
  ];

  return (
    <div className="sim-modal-overlay" onClick={onClose}>
      <div className="sim-modal" onClick={e => e.stopPropagation()}>
        <div className="sim-head">
          <div className="sim-head-title">
            <div className="brand-mark" style={{ width: 32, height: 32 }}>
              <MonitorPlay size={17} />
            </div>
            <div>
              <h3>YouTube Feed Simulator</h3>
              <p>Evaluate visual pop, contrast, and clickability in realistic feeds</p>
            </div>
          </div>

          <div className="sim-tabs">
            <button
              className={`sim-tab ${viewMode === 'desktop' ? 'active' : ''}`}
              onClick={() => setViewMode('desktop')}
            >
              <Laptop size={14} /> Desktop Feed
            </button>
            <button
              className={`sim-tab ${viewMode === 'mobile' ? 'active' : ''}`}
              onClick={() => setViewMode('mobile')}
            >
              <Smartphone size={14} /> Mobile Feed
            </button>
            <button
              className={`sim-tab ${viewMode === 'sidebar' ? 'active' : ''}`}
              onClick={() => setViewMode('sidebar')}
            >
              <PlaySquare size={14} /> Up Next / Sidebar
            </button>
          </div>

          <div className="sim-head-actions">
            <button
              className="theme-toggle-btn"
              onClick={() => setTheme(t => t === 'dark' ? 'light' : 'dark')}
              title="Toggle YouTube Dark / Light Theme"
            >
              {theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
              <span>{theme === 'dark' ? 'Light Theme' : 'Dark Theme'}</span>
            </button>
            <button className="icon-btn" onClick={onClose}><X size={18} /></button>
          </div>
        </div>

        <div className="sim-toolbar">
          <div className="sim-toolbar-group">
            {variants.length > 1 && (
              <div className="sim-variants">
                <span style={{ fontSize: '11px', color: '#9d94b4' }}>Compare Variant:</span>
                {variants.map((v, i) => (
                  <button
                    key={v.url || i}
                    className={`sim-variant-btn ${activeVariant === i ? 'active' : ''}`}
                    onClick={() => setActiveVariant(i)}
                  >
                    #{i + 1} {v.score ? `(${v.score})` : ''}
                  </button>
                ))}
              </div>
            )}

            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ fontSize: '11px', color: '#9d94b4' }}>Duration:</span>
              <select className="sim-select" value={timestamp} onChange={e => setTimestamp(e.target.value)}>
                <option value="14:28">14:28 (Standard)</option>
                <option value="08:15">08:15 (Short)</option>
                <option value="42:50">42:50 (Podcast / Long)</option>
                <option value="LIVE">🔴 LIVE</option>
              </select>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <span style={{ fontSize: '11px', color: '#9d94b4' }}>Stats:</span>
              <select className="sim-select" value={viewsStats} onChange={e => setViewsStats(e.target.value)}>
                <option value="184K views • 2 hours ago">184K views • 2 hours ago (Viral)</option>
                <option value="1.2M views • 1 day ago">1.2M views • 1 day ago (Mega)</option>
                <option value="12K views • 4 hours ago">12K views • 4 hours ago (Standard)</option>
                <option value="850 views • 30 minutes ago">850 views • 30 mins ago (Fresh)</option>
              </select>
            </div>
          </div>

          <div className="sim-toolbar-group">
            <label className="sim-toggle">
              <input
                type="checkbox"
                checked={showProgress}
                onChange={e => setShowProgress(e.target.checked)}
              />
              <span>Simulate Watched Bar</span>
            </label>
            <label className="sim-toggle">
              <input
                type="checkbox"
                checked={showDeadZone}
                onChange={e => setShowDeadZone(e.target.checked)}
              />
              <span>Highlight Dead-Zone</span>
            </label>
          </div>
        </div>

        <div className={`sim-body yt-theme-${theme}`}>
          <div className="yt-container">
            <div className="yt-header-bar">
              <div className="yt-logo">
                <span className="yt-logo-badge">YT</span>
                <span>YouTube</span>
              </div>
              <div className="yt-search-fake">
                <Search size={14} />
                <span>{currentTitle.slice(0, 35)}...</span>
              </div>
              <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                <Bell size={16} />
                <div className="yt-avatar" style={{ background: '#7c3aed', width: 28, height: 28, fontSize: 11 }}>
                  {channelName?.[0] || 'Y'}
                </div>
              </div>
            </div>

            <div className="yt-chips">
              <span className="yt-chip active">All</span>
              <span className="yt-chip">{data.category || 'Vlog'}</span>
              <span className="yt-chip">Kannada Cinema</span>
              <span className="yt-chip">Podcasts</span>
              <span className="yt-chip">Trending</span>
              <span className="yt-chip">Recently uploaded</span>
            </div>

            {viewMode === 'desktop' && (
              <div className="yt-desktop-feed">
                <div className="yt-card creator-card">
                  <div className="yt-creator-badge">★ YOUR THUMBNAIL #{activeVariant + 1}</div>
                  <div className="yt-thumb-wrap">
                    <img src={assetUrl(currentImg)} alt="Your thumbnail" />
                    <span className={`yt-duration-badge ${timestamp === 'LIVE' ? 'live' : ''}`}>{timestamp}</span>
                    {showProgress && <div className="yt-progress-bar" style={{ width: '55%' }} />}
                    {showDeadZone && <div className="yt-deadzone-box">DEAD ZONE</div>}
                  </div>
                  <div className="yt-info-row">
                    <div className="yt-avatar" style={{ background: 'linear-gradient(135deg, #a78bfa, #7c3aed)' }}>
                      {channelName?.[0]?.toUpperCase() || 'C'}
                    </div>
                    <div className="yt-meta-col">
                      <div className="yt-video-title">{currentTitle}</div>
                      <div className="yt-channel-name">
                        <span>{channelName}</span>
                        <Check size={12} color="#888" strokeWidth={3} />
                      </div>
                      <div className="yt-stats-line">{viewsStats}</div>
                    </div>
                  </div>
                </div>

                {competitors.map(c => (
                  <div className="yt-card" key={c.id}>
                    <div className="yt-thumb-wrap" style={{ background: c.bgGrad, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', textAlign: 'center', padding: '16px' }}>
                      <div style={{ fontWeight: 800, fontSize: '15px', letterSpacing: '0.8px', textShadow: '0 2px 8px rgba(0,0,0,0.8)' }}>
                        {c.badge}
                      </div>
                      <span className="yt-duration-badge">{c.time}</span>
                    </div>
                    <div className="yt-info-row">
                      <div className="yt-avatar" style={{ background: '#3b2f56' }}>
                        {c.channel[0]}
                      </div>
                      <div className="yt-meta-col">
                        <div className="yt-video-title">{c.title}</div>
                        <div className="yt-channel-name">
                          <span>{c.channel}</span>
                          <Check size={12} color="#888" strokeWidth={3} />
                        </div>
                        <div className="yt-stats-line">{c.views}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {viewMode === 'mobile' && (
              <div className="yt-mobile-wrapper">
                <div className="yt-phone-frame">
                  <div className="yt-phone-notch">
                    <span>9:41</span>
                    <span>●●● 5G 100%</span>
                  </div>
                  <div className="yt-mobile-searchbar">
                    <ChevronRight size={16} style={{ transform: 'rotate(180deg)' }} />
                    <span style={{ flex: 1, opacity: 0.8 }}>{currentTitle.slice(0, 30)}</span>
                    <Search size={16} />
                  </div>
                  <div className="yt-mobile-feed">
                    <div className="yt-card creator-card">
                      <div className="yt-creator-badge">★ YOUR THUMBNAIL</div>
                      <div className="yt-thumb-wrap">
                        <img src={assetUrl(currentImg)} alt="Your thumbnail" />
                        <span className={`yt-duration-badge ${timestamp === 'LIVE' ? 'live' : ''}`}>{timestamp}</span>
                        {showProgress && <div className="yt-progress-bar" style={{ width: '45%' }} />}
                        {showDeadZone && <div className="yt-deadzone-box">DEAD ZONE</div>}
                      </div>
                      <div className="yt-info-row">
                        <div className="yt-avatar" style={{ background: '#7c3aed', width: 32, height: 32, fontSize: 12 }}>
                          {channelName?.[0] || 'C'}
                        </div>
                        <div className="yt-meta-col">
                          <div className="yt-video-title" style={{ fontSize: '13.5px' }}>{currentTitle}</div>
                          <div className="yt-channel-name" style={{ fontSize: '11.5px' }}>{channelName} • {viewsStats}</div>
                        </div>
                      </div>
                    </div>

                    <div className="yt-card">
                      <div className="yt-thumb-wrap" style={{ background: competitors[0].bgGrad, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <span style={{ fontWeight: 800 }}>TECH RECOMMENDATION</span>
                        <span className="yt-duration-badge">{competitors[0].time}</span>
                      </div>
                      <div className="yt-info-row">
                        <div className="yt-avatar" style={{ background: '#4c3873', width: 32, height: 32, fontSize: 12 }}>
                          {competitors[0].channel[0]}
                        </div>
                        <div className="yt-meta-col">
                          <div className="yt-video-title" style={{ fontSize: '13.5px' }}>{competitors[0].title}</div>
                          <div className="yt-channel-name" style={{ fontSize: '11.5px' }}>{competitors[0].channel} • {competitors[0].views}</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {viewMode === 'sidebar' && (
              <div className="yt-sidebar-layout">
                <div>
                  <div className="yt-player-mock">
                    <div style={{ textAlign: 'center' }}>
                      <PlaySquare size={48} style={{ opacity: 0.6, marginBottom: 8 }} />
                      <div style={{ fontSize: '13px', opacity: 0.8 }}>Currently Playing Video Simulation</div>
                    </div>
                    <div className="yt-player-controls">
                      <span>▶</span>
                      <div style={{ flex: 1, height: 3, background: 'rgba(255,255,255,0.3)', borderRadius: 2 }}>
                        <div style={{ width: '38%', height: '100%', background: '#f00' }} />
                      </div>
                      <span>04:12 / 18:30</span>
                      <span>HD ⚙ ⛶</span>
                    </div>
                  </div>
                  <div style={{ marginTop: '12px' }}>
                    <h3 style={{ fontSize: '17px', margin: '0 0 6px' }}>YouTube Watch Page Context</h3>
                    <p style={{ fontSize: '12px', opacity: 0.7, margin: 0 }}>
                      Notice how your thumbnail on the right sidebar competes directly with viewer attention while they watch another video.
                    </p>
                  </div>
                </div>

                <div className="yt-sidebar-list">
                  <div className="eyebrow" style={{ color: '#a78bfa' }}>★ #1 UP NEXT (YOUR THUMBNAIL)</div>
                  <div className="yt-sidebar-item" style={{ background: 'rgba(124, 58, 237, 0.1)', padding: 8, borderRadius: 10, border: '1px solid rgba(124, 58, 237, 0.25)' }}>
                    <div className="yt-sidebar-thumb">
                      <img src={assetUrl(currentImg)} alt="Your thumbnail" />
                      <span className={`yt-duration-badge ${timestamp === 'LIVE' ? 'live' : ''}`}>{timestamp}</span>
                      {showDeadZone && <div className="yt-deadzone-box">DEAD ZONE</div>}
                    </div>
                    <div className="yt-sidebar-info">
                      <div className="yt-sidebar-title">{currentTitle}</div>
                      <div className="yt-sidebar-channel">{channelName}</div>
                      <div className="yt-sidebar-views">{viewsStats}</div>
                    </div>
                  </div>

                  {competitors.map(c => (
                    <div className="yt-sidebar-item" key={c.id}>
                      <div className="yt-sidebar-thumb" style={{ background: c.bgGrad, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                        <span style={{ fontSize: '10px', fontWeight: 800, color: '#fff' }}>{c.badge}</span>
                        <span className="yt-duration-badge">{c.time}</span>
                      </div>
                      <div className="yt-sidebar-info">
                        <div className="yt-sidebar-title">{c.title}</div>
                        <div className="yt-sidebar-channel">{c.channel}</div>
                        <div className="yt-sidebar-views">{c.views}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// HELPER: Compute Logistic Win Probability & Factors
// -------------------------------------------------------------
function computeBattleStats(a, b) {
  const scoreA = Number(a?.score ?? 85);
  const scoreB = Number(b?.score ?? 78);
  const diff = scoreA - scoreB;
  const rawProbA = Math.round(100 / (1 + Math.exp(-diff / 10)));
  const probA = Math.min(95, Math.max(5, rawProbA));
  const probB = 100 - probA;

  const factorsA = a?.factors || { faceAttention: 88, titleReadability: 91, visualBalance: 86, subjectProminence: 84 };
  const factorsB = b?.factors || { faceAttention: 80, titleReadability: 82, visualBalance: 81, subjectProminence: 79 };

  return { scoreA, scoreB, probA, probB, factorsA, factorsB, winner: diff >= 0 ? 'A' : 'B' };
}

// -------------------------------------------------------------
// MODAL: Multi-Format Resizer & Creator Pack Export
// -------------------------------------------------------------
function MultiFormatModal({ data, onClose }) {
  const [downloading, setDownloading] = useState(false);
  const canvas169Ref = useRef(null);
  const canvas916Ref = useRef(null);
  const canvas11Ref = useRef(null);

  const title = data.title || 'YouTube Thumbnail';
  const rawUrl = data.url;

  useEffect(() => {
    if (!rawUrl) return;
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src = assetUrl(rawUrl);
    img.onload = () => {
      // 1. Render 16:9 Standard (1280x720)
      if (canvas169Ref.current) {
        const c = canvas169Ref.current;
        c.width = 1280; c.height = 720;
        const ctx = c.getContext('2d');
        ctx.drawImage(img, 0, 0, 1280, 720);
      }

      // 2. Render 9:16 Shorts / Reels Cover (1080x1920)
      if (canvas916Ref.current) {
        const c = canvas916Ref.current;
        c.width = 1080; c.height = 1920;
        const ctx = c.getContext('2d');
        const grad = ctx.createLinearGradient(0, 0, 0, 1920);
        grad.addColorStop(0, '#0a0714');
        grad.addColorStop(0.25, '#180f2d');
        grad.addColorStop(0.75, '#180f2d');
        grad.addColorStop(1, '#0a0714');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 1080, 1920);

        ctx.save();
        ctx.filter = 'blur(40px) brightness(0.6)';
        ctx.drawImage(img, -100, 200, 1280, 1500);
        ctx.restore();

        const thumbH = Math.round((1080 / 16) * 9);
        const thumbY = (1920 - thumbH) / 2;
        ctx.drawImage(img, 0, thumbY, 1080, thumbH);

        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.roundRect(40, 140, 180, 52, 12);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = '900 24px Impact, sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('⚡ SHORTS', 130, 166);

        ctx.font = '900 48px "Nirmala UI", "Arial Black", sans-serif';
        ctx.fillStyle = '#ffffff';
        ctx.textAlign = 'left';
        ctx.shadowColor = 'rgba(0,0,0,0.8)';
        ctx.shadowBlur = 15;
        const lines = title.length > 25 ? [title.slice(0, 25), title.slice(25, 55)] : [title];
        lines.forEach((l, idx) => {
          ctx.fillText(l, 40, 260 + (idx * 55));
        });

        ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
        ctx.strokeStyle = '#a78bfa';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.roundRect(140, 1700, 800, 90, 24);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#fef08a';
        ctx.font = '900 36px "Nirmala UI", sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('👉 WATCH FULL VIDEO', 540, 1755);
      }

      // 3. Render 1:1 Community / Instagram Post (1080x1080)
      if (canvas11Ref.current) {
        const c = canvas11Ref.current;
        c.width = 1080; c.height = 1080;
        const ctx = c.getContext('2d');
        const grad = ctx.createLinearGradient(0, 0, 1080, 1080);
        grad.addColorStop(0, '#100c1e');
        grad.addColorStop(0.5, '#1e1338');
        grad.addColorStop(1, '#090611');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, 1080, 1080);

        ctx.save();
        ctx.filter = 'blur(50px) brightness(0.7)';
        ctx.drawImage(img, 40, 180, 1000, 700);
        ctx.restore();

        const thumbH = Math.round((1000 / 16) * 9);
        const thumbY = (1080 - thumbH) / 2;
        ctx.drawImage(img, 40, thumbY, 1000, thumbH);

        ctx.strokeStyle = 'rgba(255,255,255,0.2)';
        ctx.lineWidth = 3;
        ctx.strokeRect(40, thumbY, 1000, thumbH);

        ctx.fillStyle = '#8b5cf6';
        ctx.beginPath();
        ctx.roundRect(40, 90, 280, 48, 10);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = '900 22px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('COMMUNITY POST', 180, 122);

        ctx.fillStyle = '#ffffff';
        ctx.font = '900 34px "Nirmala UI", sans-serif';
        ctx.textAlign = 'center';
        ctx.shadowColor = 'rgba(0,0,0,0.9)';
        ctx.shadowBlur = 10;
        ctx.fillText(title.slice(0, 45), 540, 990);
      }
    };
  }, [rawUrl, title]);

  function downloadCanvas(canvas, filename) {
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = filename;
    link.href = canvas.toDataURL('image/png');
    link.click();
  }

  function downloadAll() {
    setDownloading(true);
    setTimeout(() => {
      downloadCanvas(canvas169Ref.current, 'thumblify-16x9-standard.png');
      setTimeout(() => {
        downloadCanvas(canvas916Ref.current, 'thumblify-9x16-shorts-reels.png');
        setTimeout(() => {
          downloadCanvas(canvas11Ref.current, 'thumblify-1x1-community-post.png');
          setDownloading(false);
        }, 300);
      }, 300);
    }, 100);
  }

  return (
    <div className="sim-modal-backdrop" onClick={onClose}>
      <div className="mf-modal" onClick={e => e.stopPropagation()}>
        <div className="sim-modal-header">
          <div>
            <div className="eyebrow" style={{ color: '#a78bfa' }}>CREATOR PACK MULTI-FORMAT EXPORT</div>
            <h2>Export Multi-Format Resizes</h2>
          </div>
          <div style={{ display: 'flex', gap: '10px', alignItems: 'center' }}>
            <button className="btn primary sm" onClick={downloadAll} disabled={downloading}>
              <Download size={14} /> {downloading ? 'Exporting Pack...' : 'Download Creator Pack (All 3)'}
            </button>
            <button className="sim-close-btn" onClick={onClose}><X size={20} /></button>
          </div>
        </div>

        <div className="mf-grid">
          {/* Card 1: 16:9 Standard */}
          <div className="mf-card">
            <div className="mf-card-head">
              <b>16:9 YouTube Standard</b>
              <span className="mf-tag">1280 × 720</span>
            </div>
            <div className="mf-preview-wrap" style={{ aspectRatio: '16 / 9' }}>
              <canvas ref={canvas169Ref} />
            </div>
            <div className="mf-card-info">
              Primary desktop and mobile YouTube search, browse feed, and suggested video thumbnail.
            </div>
            <button className="btn secondary sm wide" onClick={() => downloadCanvas(canvas169Ref.current, 'thumblify-16x9.png')}>
              <Download size={13} /> Export 16:9 PNG
            </button>
          </div>

          {/* Card 2: 9:16 Shorts */}
          <div className="mf-card">
            <div className="mf-card-head">
              <b>9:16 Shorts & Reels</b>
              <span className="mf-tag">1080 × 1920</span>
            </div>
            <div className="mf-preview-wrap" style={{ aspectRatio: '9 / 16', maxHeight: '250px' }}>
              <canvas ref={canvas916Ref} />
            </div>
            <div className="mf-card-info">
              Vertical full-bleed cover with ambient blur glow for YouTube Shorts, Instagram Reels, and TikTok.
            </div>
            <button className="btn secondary sm wide" onClick={() => downloadCanvas(canvas916Ref.current, 'thumblify-9x16-shorts.png')}>
              <Download size={13} /> Export 9:16 PNG
            </button>
          </div>

          {/* Card 3: 1:1 Square */}
          <div className="mf-card">
            <div className="mf-card-head">
              <b>1:1 Community & IG</b>
              <span className="mf-tag">1080 × 1080</span>
            </div>
            <div className="mf-preview-wrap" style={{ aspectRatio: '1 / 1', maxHeight: '250px' }}>
              <canvas ref={canvas11Ref} />
            </div>
            <div className="mf-card-info">
              Square aspect ratio designed for YouTube Community tab polls/updates and Instagram feed posts.
            </div>
            <button className="btn secondary sm wide" onClick={() => downloadCanvas(canvas11Ref.current, 'thumblify-1x1-square.png')}>
              <Download size={13} /> Export 1:1 PNG
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// MODAL: A/B Battle Arena & CTR Predictor
// -------------------------------------------------------------
function AbBattleArena({ data, onClose, openSimulator }) {
  const candidateA = data.variantA;
  const candidateB = data.variantB;

  if (!candidateA || !candidateB) return null;

  const { scoreA, scoreB, probA, probB, factorsA, factorsB, winner } = computeBattleStats(candidateA, candidateB);

  return (
    <div className="sim-modal-backdrop" onClick={onClose}>
      <div className="ab-modal" onClick={e => e.stopPropagation()}>
        <div className="sim-modal-header">
          <div>
            <div className="eyebrow" style={{ color: '#ec4899' }}>HEAD-TO-HEAD A/B PREDICTOR</div>
            <h2>A/B Battle Arena</h2>
          </div>
          <button className="sim-close-btn" onClick={onClose}><X size={20} /></button>
        </div>

        <div className="ab-arena-grid">
          {/* Candidate A */}
          <div className={`ab-card-col ${winner === 'A' ? 'winner' : ''}`}>
            <div className="ab-select-row">
              <span className="eyebrow">CANDIDATE A</span>
              <span className="mf-tag" style={{ background: '#059669', color: '#ecfdf5' }}>{probA}% Win Chance</span>
            </div>
            <div className="ab-thumb-wrap">
              <img src={assetUrl(candidateA.url)} alt="Candidate A" />
            </div>
            <div className="ab-score-pill">
              <Sparkles size={14} color="#10b981" />
              <span>Score: {scoreA}/100</span>
              <small style={{ color: '#9d94b4', marginLeft: 'auto' }}>{candidateA.layout || 'Layout A'}</small>
            </div>
            <div className="ab-stats-list">
              <div className="ab-stat-item"><span>Face Attention</span><b>{factorsA.faceAttention}%</b></div>
              <div className="ab-stat-item"><span>Title Readability</span><b>{factorsA.titleReadability}%</b></div>
              <div className="ab-stat-item"><span>Visual Balance</span><b>{factorsA.visualBalance}%</b></div>
              <div className="ab-stat-item"><span>Prominence</span><b>{factorsA.subjectProminence}%</b></div>
            </div>
          </div>

          {/* Center VS Divider */}
          <div className="ab-vs-divider">
            <div className="ab-vs-circle">VS</div>
            <span style={{ fontSize: '11px', color: '#9d94b4', fontWeight: 600 }}>CTR IMPACT</span>
            <button
              className="btn accent sm"
              style={{ marginTop: '8px' }}
              onClick={() => {
                onClose();
                openSimulator(candidateA, candidateA.label || 'Candidate A');
              }}
            >
              <MonitorPlay size={13} /> Feed Battle
            </button>
          </div>

          {/* Candidate B */}
          <div className={`ab-card-col ${winner === 'B' ? 'winner' : ''}`}>
            <div className="ab-select-row">
              <span className="eyebrow">CANDIDATE B</span>
              <span className="mf-tag" style={{ background: '#e11d48', color: '#fff1f2' }}>{probB}% Win Chance</span>
            </div>
            <div className="ab-thumb-wrap">
              <img src={assetUrl(candidateB.url)} alt="Candidate B" />
            </div>
            <div className="ab-score-pill">
              <Sparkles size={14} color="#f43f5e" />
              <span>Score: {scoreB}/100</span>
              <small style={{ color: '#9d94b4', marginLeft: 'auto' }}>{candidateB.layout || 'Layout B'}</small>
            </div>
            <div className="ab-stats-list">
              <div className="ab-stat-item"><span>Face Attention</span><b>{factorsB.faceAttention}%</b></div>
              <div className="ab-stat-item"><span>Title Readability</span><b>{factorsB.titleReadability}%</b></div>
              <div className="ab-stat-item"><span>Visual Balance</span><b>{factorsB.visualBalance}%</b></div>
              <div className="ab-stat-item"><span>Prominence</span><b>{factorsB.subjectProminence}%</b></div>
            </div>
          </div>
        </div>

        {/* Prediction Panel */}
        <div className="ab-prediction-panel">
          <div className="ab-probability-bar-wrap">
            <div className="ab-prob-labels">
              <span style={{ color: '#10b981' }}>Candidate A ({probA}%)</span>
              <span style={{ color: '#f43f5e' }}>Candidate B ({probB}%)</span>
            </div>
            <div className="ab-prob-bar">
              <div className="ab-prob-fill-a" style={{ width: `${probA}%` }} />
              <div className="ab-prob-fill-b" style={{ width: `${probB}%` }} />
            </div>
          </div>

          <div className="ab-insight-box">
            <Zap size={16} color="#10b981" />
            <span>
              <strong>Heuristic A/B Recommendation:</strong> {winner === 'A' ? 'Candidate A' : 'Candidate B'} demonstrates superior visual contrast and focal alignment. YouTube viewers make click decisions in under 400ms, giving {winner === 'A' ? 'Candidate A' : 'Candidate B'} a statistically significant advantage in search and suggested browse feeds.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// -------------------------------------------------------------
// PAGE: A/B Battle & CTR Predictor Arena
// -------------------------------------------------------------
function AbBattlePage({ variants, title, openSimulator, setPage }) {
  const [indexA, setIndexA] = useState(0);
  const [indexB, setIndexB] = useState(variants.length > 1 ? 1 : 0);

  if (!variants || variants.length < 2) {
    return (
      <>
        <div className="page-heading">
          <div>
            <div className="eyebrow">HEAD-TO-HEAD CTR OPTIMIZATION</div>
            <h1>A/B Battle Arena</h1>
            <p>Compare two thumbnail candidates side-by-side, estimate comparative win probabilities, and test in YouTube search.</p>
          </div>
        </div>
        <div className="empty-state">
          <div className="empty-icon"><Swords size={28} /></div>
          <h3>Need at least 2 thumbnail candidates</h3>
          <p>Generate thumbnails first to compare candidates head-to-head in the A/B Battle Arena.</p>
          <button className="btn primary" onClick={() => setPage('Generate Thumbnail')}>
            <WandSparkles size={16} /> Go to Generator
          </button>
        </div>
      </>
    );
  }

  const candidateA = variants[indexA] || variants[0];
  const candidateB = variants[indexB] || variants[1];
  const { scoreA, scoreB, probA, probB, factorsA, factorsB, winner } = computeBattleStats(candidateA, candidateB);

  return (
    <>
      <div className="page-heading">
        <div>
          <div className="eyebrow">HEAD-TO-HEAD CTR OPTIMIZATION</div>
          <h1>A/B Battle Arena</h1>
          <p>Side-by-side comparative scoring, win probability modeling, and simulated YouTube feed battle.</p>
        </div>
        <button
          className="btn accent"
          onClick={() => openSimulator(candidateA, title || 'A/B Battle Arena')}
        >
          <MonitorPlay size={16} /> Battle in YouTube Feed
        </button>
      </div>

      <div className="ab-modal" style={{ maxWidth: '100%', border: 'none', background: 'transparent', boxShadow: 'none' }}>
        <div className="ab-arena-grid" style={{ padding: 0 }}>
          {/* Candidate A */}
          <div className={`ab-card-col ${winner === 'A' ? 'winner' : ''}`}>
            <div className="ab-select-row">
              <label style={{ margin: 0, fontSize: '11px', color: '#a78bfa', fontWeight: 700 }}>
                SELECT CANDIDATE A
                <select
                  value={indexA}
                  onChange={e => setIndexA(Number(e.target.value))}
                  style={{ marginTop: '4px', background: '#120d20', color: '#fff', border: '1px solid #3d2f5a', borderRadius: '6px', padding: '4px 8px', width: '100%' }}
                >
                  {variants.map((v, i) => (
                    <option key={i} value={i}>Candidate #{i + 1} — {v.label || v.layout} ({v.score} pts)</option>
                  ))}
                </select>
              </label>
              <span className="mf-tag" style={{ background: '#059669', color: '#ecfdf5', alignSelf: 'flex-start', marginTop: '18px' }}>
                {probA}% Win Chance
              </span>
            </div>
            <div className="ab-thumb-wrap">
              <img src={assetUrl(candidateA.url)} alt="Candidate A" />
            </div>
            <div className="ab-score-pill">
              <Sparkles size={14} color="#10b981" />
              <span>Score: {scoreA}/100</span>
              <small style={{ color: '#9d94b4', marginLeft: 'auto' }}>{candidateA.layout || 'Layout A'}</small>
            </div>
            <div className="ab-stats-list">
              <div className="ab-stat-item"><span>Face Attention</span><b>{factorsA.faceAttention}%</b></div>
              <div className="ab-stat-item"><span>Title Readability</span><b>{factorsA.titleReadability}%</b></div>
              <div className="ab-stat-item"><span>Visual Balance</span><b>{factorsA.visualBalance}%</b></div>
              <div className="ab-stat-item"><span>Subject Prominence</span><b>{factorsA.subjectProminence}%</b></div>
            </div>
          </div>

          {/* Center VS Divider */}
          <div className="ab-vs-divider">
            <div className="ab-vs-circle">VS</div>
            <span style={{ fontSize: '11px', color: '#9d94b4', fontWeight: 600 }}>HEAD-TO-HEAD</span>
            <button
              className="btn secondary sm"
              style={{ marginTop: '8px' }}
              onClick={() => {
                const temp = indexA;
                setIndexA(indexB);
                setIndexB(temp);
              }}
            >
              <RotateCw size={13} /> Swap
            </button>
          </div>

          {/* Candidate B */}
          <div className={`ab-card-col ${winner === 'B' ? 'winner' : ''}`}>
            <div className="ab-select-row">
              <label style={{ margin: 0, fontSize: '11px', color: '#ec4899', fontWeight: 700 }}>
                SELECT CANDIDATE B
                <select
                  value={indexB}
                  onChange={e => setIndexB(Number(e.target.value))}
                  style={{ marginTop: '4px', background: '#120d20', color: '#fff', border: '1px solid #3d2f5a', borderRadius: '6px', padding: '4px 8px', width: '100%' }}
                >
                  {variants.map((v, i) => (
                    <option key={i} value={i}>Candidate #{i + 1} — {v.label || v.layout} ({v.score} pts)</option>
                  ))}
                </select>
              </label>
              <span className="mf-tag" style={{ background: '#e11d48', color: '#fff1f2', alignSelf: 'flex-start', marginTop: '18px' }}>
                {probB}% Win Chance
              </span>
            </div>
            <div className="ab-thumb-wrap">
              <img src={assetUrl(candidateB.url)} alt="Candidate B" />
            </div>
            <div className="ab-score-pill">
              <Sparkles size={14} color="#f43f5e" />
              <span>Score: {scoreB}/100</span>
              <small style={{ color: '#9d94b4', marginLeft: 'auto' }}>{candidateB.layout || 'Layout B'}</small>
            </div>
            <div className="ab-stats-list">
              <div className="ab-stat-item"><span>Face Attention</span><b>{factorsB.faceAttention}%</b></div>
              <div className="ab-stat-item"><span>Title Readability</span><b>{factorsB.titleReadability}%</b></div>
              <div className="ab-stat-item"><span>Visual Balance</span><b>{factorsB.visualBalance}%</b></div>
              <div className="ab-stat-item"><span>Subject Prominence</span><b>{factorsB.subjectProminence}%</b></div>
            </div>
          </div>
        </div>

        {/* Prediction Panel */}
        <div className="ab-prediction-panel" style={{ borderRadius: '12px', marginTop: '16px' }}>
          <div className="ab-probability-bar-wrap">
            <div className="ab-prob-labels">
              <span style={{ color: '#10b981', fontWeight: 800 }}>Candidate A ({probA}% Win Probability)</span>
              <span style={{ color: '#f43f5e', fontWeight: 800 }}>Candidate B ({probB}% Win Probability)</span>
            </div>
            <div className="ab-prob-bar">
              <div className="ab-prob-fill-a" style={{ width: `${probA}%` }} />
              <div className="ab-prob-fill-b" style={{ width: `${probB}%` }} />
            </div>
          </div>

          <div className="ab-insight-box">
            <Zap size={18} color="#10b981" />
            <div>
              <strong>Heuristic Recommendation:</strong> {winner === 'A' ? 'Candidate A' : 'Candidate B'} holds a statistical edge with stronger visual hierarchy and higher readability outside the YouTube mobile dead-zone.
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

// -------------------------------------------------------------
// MODAL: Professional Thumbnail Quality Audit Certificate (Print / PDF)
// -------------------------------------------------------------
function AuditCertificateModal({ data, onClose }) {
  const variant = data.variant || {};
  const title = data.title || 'YouTube Thumbnail';
  const category = data.category || 'Vlog';
  const language = data.language || 'Bilingual';
  const score = variant.score || 94;
  const factors = variant.factors || {
    faceAttention: 92,
    titleReadability: 94,
    visualBalance: 88,
    colorContrast: 95,
    subjectProminence: 86,
    complexityMinimization: 91,
    safeZoneClearance: 98
  };

  const auditId = 'THUMB-AUDIT-' + Math.floor(100000 + Math.random() * 900000);
  const auditDate = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="sim-modal-backdrop" onClick={onClose}>
      <div className="audit-cert-modal" onClick={e => e.stopPropagation()}>
        <div className="sim-modal-header no-print">
          <div>
            <div className="eyebrow" style={{ color: '#10b981' }}>QUALITY CERTIFICATION ENGINE</div>
            <h2>Official Thumbnail Audit Certificate</h2>
          </div>
          <div style={{ display: 'flex', gap: '10px' }}>
            <button className="btn primary sm" onClick={() => window.print()}>
              <Printer size={14} /> Print / Save as PDF
            </button>
            <button className="sim-close-btn" onClick={onClose}><X size={20} /></button>
          </div>
        </div>

        <div className="cert-border">
          <div className="cert-head">
            <div>
              <div style={{ fontSize: '11px', fontWeight: 800, color: '#a78bfa', letterSpacing: '1px' }}>THUMBLIFY AI EVALUATION ARCHITECTURE</div>
              <h1 style={{ fontSize: '22px', fontWeight: 900, margin: '4px 0', color: '#f1edff' }}>THUMBNAIL QUALITY & CTR AUDIT CERTIFICATE</h1>
              <p style={{ fontSize: '11px', color: '#9d94b4', margin: 0 }}>Certificate ID: <b>{auditId}</b> • Verified on {auditDate}</p>
            </div>
            <div className="cert-seal">
              <span>GRADE</span>
              <span style={{ fontSize: '18px', fontWeight: 900 }}>A+</span>
              <span>VERIFIED</span>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '16px', alignItems: 'center' }}>
            <div style={{ borderRadius: '10px', overflow: 'hidden', border: '1px solid #362952', background: '#0a0715' }}>
              <img src={assetUrl(variant.url)} alt="Audited Thumbnail" style={{ width: '100%', display: 'block', aspectRatio: '16 / 9', objectFit: 'cover' }} />
            </div>
            <div style={{ background: '#171129', padding: '14px', borderRadius: '10px', border: '1px solid #2d2146' }}>
              <div style={{ fontSize: '11px', color: '#a78bfa', fontWeight: 700 }}>OVERALL CTR QUALITY SCORE</div>
              <div style={{ fontSize: '42px', fontWeight: 900, color: '#10b981', margin: '2px 0' }}>{score}<small style={{ fontSize: '16px', color: '#9d94b4' }}>/100</small></div>
              <div style={{ fontSize: '11px', color: '#e2d9f3', lineHeight: 1.4 }}>
                Layout: <b>{variant.label || variant.layout || 'Left Subject Anchor'}</b><br />
                Language: <b>{language}</b> • Category: <b>{category}</b><br />
                Title: <i>"{title.slice(0, 40)}"</i>
              </div>
            </div>
          </div>

          <table className="cert-metrics-table">
            <thead>
              <tr>
                <th>Heuristic Dimension</th>
                <th>Weight</th>
                <th>Raw Score</th>
                <th>Compliance Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td><b>Face & Emotional Attention</b></td>
                <td>25%</td>
                <td>{factors.faceAttention}%</td>
                <td><span style={{ color: '#10b981', fontWeight: 700 }}>✓ PASS (High Eye Contact)</span></td>
              </tr>
              <tr>
                <td><b>Title Readability (Contrast Ratio)</b></td>
                <td>20%</td>
                <td>{factors.titleReadability}%</td>
                <td><span style={{ color: '#10b981', fontWeight: 700 }}>✓ PASS (WCAG AAA ≥ 7:1)</span></td>
              </tr>
              <tr>
                <td><b>Visual Balance & Asymmetry</b></td>
                <td>15%</td>
                <td>{factors.visualBalance}%</td>
                <td><span style={{ color: '#10b981', fontWeight: 700 }}>✓ PASS (Rule-of-Thirds)</span></td>
              </tr>
              <tr>
                <td><b>Color Separation & Depth</b></td>
                <td>15%</td>
                <td>{factors.colorContrast || 94}%</td>
                <td><span style={{ color: '#10b981', fontWeight: 700 }}>✓ PASS (Foreground Cutout)</span></td>
              </tr>
              <tr>
                <td><b>Subject Prominence</b></td>
                <td>10%</td>
                <td>{factors.subjectProminence}%</td>
                <td><span style={{ color: '#10b981', fontWeight: 700 }}>✓ PASS (35% Canvas Fill)</span></td>
              </tr>
              <tr>
                <td><b>YouTube Mobile Timestamp Clearance</b></td>
                <td>7%</td>
                <td>{factors.safeZoneClearance || 98}%</td>
                <td><span style={{ color: '#10b981', fontWeight: 700 }}>✓ VERIFIED (Zero Occlusion)</span></td>
              </tr>
            </tbody>
          </table>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid #281a42', paddingTop: '12px', marginTop: '12px' }}>
            <div style={{ fontSize: '10.5px', color: '#9d94b4' }}>
              <b>Audited by Thumblify Heuristic Engine v2.0</b> • Evaluated across 7-dimensional attention metrics
            </div>
            <div style={{ textAlign: 'right', fontSize: '10.5px', color: '#10b981', fontWeight: 800 }}>
              🛡️ OFFICIAL CERTIFICATE OF COMPLIANCE
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
