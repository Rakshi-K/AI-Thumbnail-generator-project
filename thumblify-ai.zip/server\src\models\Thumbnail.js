import mongoose from 'mongoose';
const thumbnailSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, maxlength: 140 },
  category: { type: String, default: 'Vlog', maxlength: 40 },
  language: { type: String, enum: ['English', 'Kannada'], default: 'English' },
  emoji: { type: String, default: '' },
  variants: [{ url: String, score: Number, label: String, layout: String, factors: mongoose.Schema.Types.Mixed }],
  bestScore: { type: Number, min: 0, max: 100 },
  createdAt: { type: Date, default: Date.now, index: true }
}, { timestamps: true });
thumbnailSchema.index({ user: 1, createdAt: -1 });
export default mongoose.model('Thumbnail', thumbnailSchema);
