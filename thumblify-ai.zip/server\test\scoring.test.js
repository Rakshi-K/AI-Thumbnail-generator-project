import test from 'node:test';
import assert from 'node:assert/strict';

test('top five candidates are returned in descending score order', () => {
  const items = Array.from({length:10},(_,i)=>({score:70+i,label:`Layout ${i+1}`}));
  const topFive = items.sort((a,b)=>b.score-a.score).slice(0,5);
  assert.equal(topFive.length,5);
  assert.deepEqual(topFive.map(x=>x.score),[79,78,77,76,75]);
});

test('seven-factor ranking weights sum to one', () => {
  const weights = { faceAttention:.18, titleReadability:.20, visualBalance:.14, subjectProminence:.16, backgroundQuality:.10, composition:.12, contrast:.10 };
  assert.equal(Object.values(weights).reduce((a,b)=>a+b,0),1);
});

test('six analyzer dimensions are represented', () => {
  const dimensions = ['brightness','contrast','saturation','exposure','colorBalance','aspectRatioCompliance'];
  assert.equal(new Set(dimensions).size,6);
});

test('title wrapping limits output to three lines', () => {
  const title = 'One two three four five six seven eight nine ten eleven twelve';
  const words = title.split(' ');
  const lines = []; let line = '';
  for (const word of words) {
    if ((line + ' ' + word).trim().length > 18 && line) { lines.push(line); line = word; }
    else line = (line + ' ' + word).trim();
  }
  if (line) lines.push(line);
  assert.ok(lines.slice(0,3).length <= 3);
});
