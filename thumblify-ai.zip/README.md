# Thumblify: AI-Powered Platform for Automated YouTube Thumbnail Generation, Ranking, and Quality Analysis

---

## 📖 Overview

Thumblify is a full-stack platform for automated 16:9 YouTube thumbnail generation, multi-candidate layout ranking, and post-hoc thumbnail visual quality analysis.

The system integrates four core modules:
1. **Computer-Vision Pipeline**: Combines face detection, landmarking, and expression classification to compute a per-subject face-attention score $A_i$.
2. **Salient Background Removal**: Automatically isolates each uploaded person image ($2\text{--}6$ subjects) as a transparent foreground cutout via nested U-structure segmentation.
3. **10-Candidate Layout Ranking Engine**: Evaluates 10 layout strategies (Left/Right/Top/Center Title, Diagonal, Hero Left/Right, Group Center, Split Screen, and Dramatic) scored by a 7-factor composite quality function $Q(l_k) \in [0, 100]$ to surface the top 5 renders.
4. **Standalone Thumbnail Analyzer**: Scores an existing thumbnail out of 100 across 6 no-reference quality dimensions ($g_1 \dots g_6$: brightness, contrast, saturation, exposure, color balance, and 16:9 compliance).

---

## 🖥️ Application Modules

| Page / Module | Scope & Capabilities |
| :--- | :--- |
| **Dashboard** | Overview of generation volume, average quality score, best score, available credits, recent generations, and category telemetry. |
| **Generate Thumbnail** | Multi-subject upload ($2\text{--}6$ person photos), background upload or AI procedural lighting, bilingual Kannada/English titling, category and style selection, optional emoji, and generation of top 5 ranked renders with 7-factor score breakdown. |
| **My Generations** | History of past generation runs with layout labels, scores, download links, and direct editing. |
| **Thumbnail Analyzer** | No-reference image quality audit across brightness, contrast, saturation, exposure, color balance, and 16:9 aspect-ratio compliance with diagnostic recommendations. |
| **Editor** | Interactive post-generation canvas editor to customize headline and subtitle typography, font family (`Nirmala UI`, `Impact`, `Arial Black`, `Segoe UI`), text colors, stroke width, badge pills, sticker emojis, and real-time image grading sliders. |
| **Analytics** | Tracking of generation telemetry, average score, category distributions, and heuristic quality factor breakdown. |
| **Templates** | Reusable thumbnail recipes across categories (Kannada Serial, Vlog, News, Gaming, Devotional, Comedy, Cooking, Education) with one-click transfer into the generator. |
| **Projects** | Organization of creator thumbnail folders and brand assets. |
| **Prompt Studio** | Creative prompt engineering workspace with AI refinement and direct send to the generation studio. |
| **Settings** | Creator account profile, available credits, and Brand Kit configuration (channel name, primary/secondary colors, preferred font, default script). |

---

## 📐 Algorithmic Formulations

### 1. Per-Subject Face Attention Score ($A_i$)
$$A_i = w_c \cdot \text{conf}_i + w_s \cdot \text{size}_i + w_p \cdot (1 - d_i) + w_e \cdot \text{expr}_i$$
where $\sum w = 1$, weighting SSD-MobileNet confidence, bounding-box size ratio, centrality from composition anchor, and expression salience.

### 2. Composite Layout Quality Score ($Q(l_k)$)
$$Q(l_k) = \sum_{j=1}^7 w_j \cdot f_j(l_k), \quad \sum w_j = 1, \; f_j \in [0, 100]$$
Combining:
- Face Attention ($w_1 = 0.18$)
- Title Readability ($w_2 = 0.20$)
- Visual Balance ($w_3 = 0.14$)
- Subject Prominence ($w_4 = 0.16$)
- Background Quality ($w_5 = 0.10$)
- Composition ($w_6 = 0.12$)
- Contrast ($w_7 = 0.10$)

Top 5 candidates are surfaced: $R = \text{Top5}(\text{sort}_\downarrow \{ Q(l_k) : l_k \in L \}), |L| = 10$.

### 3. No-Reference Quality Analyzer ($Q'$)
$$Q' = \sum_{j=1}^6 v_j \cdot g_j, \quad \sum v_j = 1, \; g_j \in [0, 100]$$
Evaluating brightness, contrast, saturation, exposure, color balance, and 16:9 compliance against the 1280×720 YouTube standard.

---

## 🛠️ Technology Stack

- **Frontend:** React 18, Vite, Tailwind CSS / Studio Dark Stylesheet, Lucide React
- **Backend:** Node.js, Express.js, MongoDB via Mongoose, JWT, bcryptjs, Multer
- **Graphics & AI/CV:** Sharp, `@napi-rs/canvas`, `@imgly/background-removal-node`, `@vladmandic/face-api`

---

## ⚡ Quick Start

### 1. Start Server
```bash
cd server
npm install
npm run dev
```
Runs at `http://localhost:5000`.

### 2. Start Client
```bash
cd client
npm install
npm run dev
```
Runs at `http://localhost:5173`.

### 3. Run Unit Tests
```bash
cd server
npm test
```
